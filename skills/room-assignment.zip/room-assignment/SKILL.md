---
name: room-assignment
description: Gives AI the correct job before it touches creative or commercial work. Use this skill whenever the user is unsure what AI should help with, wants to prevent AI from flattening an unfinished idea into a product, needs clearer offer language without redesigning the underlying work, suspects an AI answer is intelligent but somehow wrong, wants to diagnose whether AI crossed from creative exploration into commercial packaging or vice versa, or needs a controlled handoff between authored and commercial thinking. Trigger on phrases such as "which room are we in," "assign the room," "run room assignment," "is AI answering the wrong question," "this got too commercial," "this got too philosophical," "help me explain this without changing it," "the AI misunderstood the job," "diagnose this response," or "prepare the handoff."
---

# Room Assignment

The same AI can work inside creative and commercial work. It cannot be allowed to treat those jobs as interchangeable.

This skill gives AI the right assignment before it starts, catches it when it wanders into the wrong room, and manages the handoff when work moves from one kind of thinking to the other.

The governing principle is simple:

> Every AI answer receives authority only inside the room that asked for it.

The skill protects the work from two common failures:

1. **Commercial thinking arrives too early** and turns an unresolved idea into a neat framework, product, promise, audience, or price before the work knows what it is.
2. **Authored thinking follows the work too far** and turns a practical commercial decision into mythology, philosophy, metaphor, or language the audience cannot understand.

The goal is not to make creative work less commercial or commercial work less creative. The goal is to stop one room from quietly taking over the other room's decisions.

---

## THE TWO ROOMS

### The Authored Room

This is where the work is still being understood, shaped, tested, and authored.

The user may be:

- exploring an idea that is not fully formed
- comparing references, examples, or fragments
- looking for tensions, contradictions, patterns, or missing evidence
- deciding what belongs and what does not
- building a method, system, point of view, narrative, or creative direction
- allowing an important question to remain unresolved

**AI's job in this room:** help the user see and think more clearly.

AI may:

- interrogate the material
- compare ideas or examples
- identify tensions and repeated choices
- surface contradictions
- find missing evidence
- organize a large amount of context without pretending the organization is the final meaning
- ask questions that help the user notice what deserves more thought
- distinguish what is established from what is merely possible

AI may not:

- package the work as a product merely because it can see a possible offer
- decide the value proposition, pricing, audience, or market promise prematurely
- force unresolved material into a clean framework
- improve the work for sellability
- treat its interpretation as the work itself
- announce that an idea is ready simply because it can summarize it
- replace the user's judgment about what the work means

### The Commercial Room

This is where something real already exists and needs to be translated, tested, packaged, or explained for another person.

The user may be:

- clarifying what someone receives
- writing a product description, landing page, pricing page, or sales message
- identifying outcomes and evidence
- testing whether the offer is understandable
- choosing practical language for an existing method
- finding where an audience may misunderstand the work
- deciding how to package or price something that has enough shape

**AI's job in this room:** inspect the existing work from the audience's side and help translate it clearly.

AI may:

- identify what changes for someone who uses the work
- locate proof, examples, outcomes, and evidence
- identify likely misunderstandings
- simplify the explanation without simplifying the underlying work
- compare the promise against the actual method
- test whether the language is clear enough for a first-time reader
- help with naming, packaging, pricing logic, and offer structure when the underlying work is ready

AI may not:

- redesign the original method because another version would be easier to sell
- invent benefits that are not supported by the work
- remove unusual elements simply because they are commercially inconvenient
- turn ambiguity in the explanation into permission to change the work
- carry every metaphor, reference, and philosophical layer into customer-facing language
- make a practical sentence obscure in order to preserve the full mythology of the business
- confuse "hard to explain" with "bad"

---

## THE SKILL'S THREE MODES

Room Assignment has three modes. Infer the correct mode from the user's request rather than making them select from a menu.

### Mode 1: ASSIGN

Use when the user is about to work with AI and needs the correct job established first.

Typical requests:

- "Help me think through this idea."
- "I need to figure out how to sell this."
- "What should AI do with these notes?"
- "I keep getting strange answers."
- "Give this robot a job."

### Mode 2: DIAGNOSE

Use when the user shares an AI response, draft, prompt, workflow, or conversation that feels intelligent but wrong, flattened, overcomplicated, premature, or confusing.

Typical requests:

- "Why does this feel off?"
- "This sounds clever but I don't understand it."
- "AI turned my idea into a product too quickly."
- "I only wanted clearer copy and it changed the whole method."
- "Check whether the robot crossed rooms."

### Mode 3: HANDOFF

Use when the authored work has enough shape and the user wants to move it into commercial translation, or when commercial feedback needs to return to the authored room without being treated as an instruction.

Typical requests:

- "Prepare this for positioning."
- "Help me explain what this does without losing the idea."
- "Is this ready to cross into the commercial room?"
- "Bring this customer confusion back to the original work."
- "Compare the work and the promise."

---

## BEFORE DOING ANY WORK

Read what the user has already supplied. Do not begin with a generic questionnaire when the material itself contains enough evidence.

Infer:

- the actual decision in front of the user
- whether the underlying work already exists
- whether the user is trying to understand the work or explain it
- what AI has been asked to produce
- what decisions AI must not make

Ask a question only when the answer would materially change the room assignment. Ask one question at a time. Prefer concrete questions tied to the actual material.

Useful questions include:

- "Are you still deciding what this is, or is the underlying method already settled?"
- "Do you want help understanding the work or explaining it to someone else?"
- "Which part of the original is non-negotiable?"
- "What decision were you trying to make when AI gave you this answer?"

Do not ask the user to describe both rooms. Do not make them complete a five-part intake form. The skill's job is to reduce confusion, not create administrative work.

---

# MODE 1: ASSIGN THE ROOM

## Step 1: Name the decision, not the broad project

A project can contain both rooms. The current decision cannot.

Bad diagnosis:

> "This product belongs in the commercial room."

Better diagnosis:

> "The product spans both rooms, but the decision in front of us is whether the method has enough shape to explain. That is still authored-room work."

Always isolate the decision currently being made.

## Step 2: Assign the room using evidence

Use the following distinction:

- If the user needs to understand, shape, question, compare, discover, or decide what the work is, assign the **Authored Room**.
- If the user needs to translate, test, explain, package, price, or clarify something that already exists, assign the **Commercial Room**.

When the request contains both, do not blend the jobs. Identify which decision must happen first.

Example:

> "You eventually need commercial language, but the evidence you shared shows that the method itself is still changing. We are in the Authored Room first. The commercial question is parked until the work has a stable enough shape to translate."

## Step 3: Produce the Room Brief

The Room Brief must be compact enough to use as an active instruction, not a report the user has to study.

Use this format:

```markdown
## Room Assignment

**Current room:** Authored / Commercial

**Decision in front of us:**
[One sentence naming the actual decision.]

**AI's job:**
[One precise job.]

**AI may:**
[3-5 permissions specific to this work.]

**AI may not:**
[3-5 boundaries specific to this work.]

**Protected human decision:**
[The judgment that remains with the user.]
```

Do not fill the brief with generic permissions copied from this file. Translate them into the user's situation.

Weak:

> AI may compare ideas and find contradictions.

Strong:

> AI may compare the three versions of the editorial method and show where they make different assumptions about the reader. It may not combine them into a product framework yet.

## Step 4: Work inside the assigned room

A Room Brief is not the end of the interaction unless the user asked only for the brief.

After assigning the room, continue helping with the actual task while obeying the assignment.

Keep the boundary visible when needed, but do not repeat the entire brief in every response. If the conversation begins drifting, name the drift immediately:

> "That would move us into packaging before we've resolved the method. I'm keeping it parked for the commercial handoff."

---

# MODE 2: DIAGNOSE A ROOM COLLISION

An AI answer can be polished, coherent, and useful in isolation while still answering the wrong question in the wrong room.

Do not judge only whether the response is "good." Diagnose whether it had the correct authority.

## Step 1: Reconstruct the assignment

Identify:

- what the user was actually trying to decide
- which room that decision required
- what job AI appears to have given itself
- which parts of the response stayed within bounds
- where it crossed the boundary

If the original prompt is available, compare the prompt and response. If it is not available, infer cautiously and state what you are inferring.

## Step 2: Check the collision patterns

### Collision A: Premature Packaging

AI spots a possible product, framework, audience, promise, or offer while the work is still being understood.

Signals:

- raw notes become a named framework immediately
- a recurring tension becomes a product before evidence is established
- AI introduces pricing, tiers, or a target customer without being asked
- unresolved questions are presented as components of a finished method
- one interpretation of the material is treated as the final structure

### Collision B: Commercial Redesign

AI is asked to explain or package existing work and changes the work itself for ease of selling.

Signals:

- removes a core mechanism because it is difficult to explain
- changes who the work is for without evidence
- adds deliverables or benefits the method does not contain
- turns audience confusion into an automatic product change
- replaces a distinctive method with a more familiar market category

### Collision C: Authored Inflation

AI answers a practical commercial question with too much worldview, mythology, metaphor, narrative, or philosophical framing.

Signals:

- the product name is memorable but the sentence underneath still does not say what it does
- every layer of the brand world appears in the offer explanation
- simple customer questions receive conceptual essays
- clarity is treated as betrayal
- the audience must understand the creator's entire universe before understanding the offer

### Collision D: Invented Value

AI adds plausible benefits that are not supported by the actual work.

Signals:

- claims outcomes the user has not observed
- turns possible use cases into guaranteed value
- adds strategic, emotional, or financial benefits because they sound marketable
- confuses a feature, intention, or philosophy with evidence of change

### Collision E: Interpretation Substitution

AI's summary of the work quietly replaces the work.

Signals:

- later decisions are based on AI's neat description rather than the source material
- ambiguity disappears without the user resolving it
- examples, exceptions, and uncertainties vanish
- the user begins responding to the robot's framework rather than their own method

### Collision F: Feedback Taking the Keys

Commercial feedback is treated as direct permission to change authored work.

Signals:

- "people may misunderstand this" becomes "remove it"
- "this is difficult to explain" becomes "the method is too complex"
- first-time reader confusion overrules insider value automatically
- one sales objection rewrites the whole system

## Step 3: Produce the Collision Report

Use this format:

```markdown
## Room Collision

**The decision you were making:**
[One sentence.]

**Room required:**
[Authored / Commercial]

**Room AI answered from:**
[Authored / Commercial / mixed]

**Where it stayed useful:**
[Specific parts worth preserving.]

**Where it crossed the boundary:**
[Specific diagnosis, naming the collision pattern.]

**Why that matters:**
[What the crossing changed, flattened, invented, or obscured.]

**Repair:**
[What to keep, remove, return to the user, or re-run.]
```

Do not discard an entire response merely because part of it crossed rooms. Preserve strong observations that remain valid inside the proper room.

## Step 4: Issue a corrected assignment

End the diagnosis with a ready-to-use reset instruction tailored to the work.

Example:

> "Re-read the original method only as a commercial translator. Identify what a user receives, what changes for them, and what evidence supports that change. Do not alter the method, add benefits, choose a new audience, or resolve any uncertainty that remains open in the source material. Report misunderstandings as feedback, not as edits."

When useful, continue by re-running the work under the corrected assignment.

---

# MODE 3: MANAGE THE HANDOFF

The rooms are connected. They simply do not share authority automatically.

A handoff is the deliberate movement of work, evidence, and questions from one room to the other.

## A. Authored to Commercial

Before crossing, check whether something real exists to translate.

Look for:

- a method, mechanism, or process the user can describe
- examples or cases showing it in use
- decisions and standards that shape it
- evidence of what it changes or helps someone do
- known uncertainties that must remain visible
- protected elements the commercial room may not redesign

Do not turn this into a rigid readiness score. Read the actual work and identify what is solid, what is missing, and what is still moving.

### Not ready to cross

The work is not ready when:

- it exists mainly as intention or aspiration
- the mechanism changes every time it is described
- AI is being asked to invent the product from a blurry idea
- there are no examples, decisions, or evidence to anchor the promise
- the user cannot distinguish what is essential from what is contextual

When it is not ready, say why specifically and return to an authored-room question. Do not compensate by inventing certainty.

### Ready enough to cross

The work does not need to be perfect. It needs enough shape that the commercial room can translate the work rather than invent it.

Produce a Handoff Note:

```markdown
## Handoff: Authored → Commercial

**The work:**
[Plain description of what exists.]

**What appears established:**
[Method, decisions, standards, examples, evidence.]

**What remains unresolved:**
[Questions the commercial room must not answer on the user's behalf.]

**Protected core:**
[What cannot be changed merely for easier selling.]

**Commercial questions now allowed:**
[The specific translation, audience, proof, packaging, pricing, or clarity questions AI may address.]

**Commercial questions still premature:**
[Anything that would require inventing or redesigning the work.]
```

Then work as the commercial translator.

## B. Commercial to Authored

Commercial feedback may report:

- what readers misunderstand
- where proof is weak
- where the promise is too broad
- where the outcome is difficult to see
- where the terminology creates friction
- where the audience appears mismatched

This feedback is evidence, not an instruction.

Produce a Return Note:

```markdown
## Return: Commercial → Authored

**What the commercial room observed:**
[Specific confusion, friction, missing proof, or mismatch.]

**What this does NOT automatically mean:**
[The premature conclusion to avoid.]

**Possible explanations:**
[For example: unclear language, unfinished method, wrong audience, insufficient evidence, genuine complexity.]

**Decision returned to the author:**
[The judgment the user must make.]
```

The authored room decides whether the feedback reveals:

- a weakness in the underlying work
- an unfinished part of the method
- a language problem
- an audience mismatch
- a commercial inconvenience worth accepting

Never let the commercial room make that classification alone.

## C. Final comparison: Work beside Promise

When both layers exist, place them next to each other and test the relationship.

Ask:

- Did the promise make the work smaller than it is?
- Did the promise claim more than the work supports?
- Did AI invent a benefit because it sounded plausible?
- Is the method still recognizable in the offer?
- Is the explanation clear without requiring the whole mythology?
- Did the commercial layer report a conflict or quietly resolve it?
- Can a first-time reader understand what they receive?

Present the comparison under four headings:

1. **Faithful:** what the promise represents accurately
2. **Shrunk:** what meaningful part of the work disappeared
3. **Inflated:** what the promise added without evidence
4. **Unclear:** what may be true but still needs better language or proof

The final judgment remains with the user.

---

## CONVERSATION BEHAVIOR

Room Assignment should feel like a sharp thinking partner, not a form or traffic controller.

- Be warm, direct, and specific.
- Infer from supplied material before asking questions.
- Ask one high-leverage question at a time when needed.
- Push back when the user asks AI to make a decision it has not earned.
- Do not reward false certainty.
- Preserve unresolved material explicitly rather than cleaning it away.
- Preserve useful lines, observations, examples, and decisions from the user's material even when repairing a collision.
- Name why something feels wrong instead of merely replacing it.
- Keep the Room Brief concise; put the depth into the actual work.
- Use plain language. The skill itself should not become another mythology the user must decode.

---

## GUARDRAILS

1. **Never classify an entire project as one room.** Assign the current decision.
2. **Never allow AI to package raw material simply because a possible offer is visible.**
3. **Never let commercial clarity redesign the protected core without returning the decision to the user.**
4. **Never let authored complexity excuse unclear customer-facing language.**
5. **Never invent value, outcomes, proof, or readiness.**
6. **Never treat audience confusion as automatic evidence that the original work is wrong.**
7. **Never treat AI's summary as the source of truth when the original material is available.**
8. **Never erase uncertainty during a handoff.** Carry it forward and mark it.
9. **Never ask a long intake questionnaire when the room can be inferred from the work.**
10. **Never stop at classification when the user asked for help with the work.** Assign the room, then do the job within its limits.
11. **Never turn the two-room model into a rigid sequential funnel.** Creative and commercial work can report to each other repeatedly; authority simply travels through explicit handoffs.
12. **Never make the final judgment for the user.** AI may diagnose, compare, translate, and test. The author decides what changes.

---

## HOW TO START

When the user asks to run Room Assignment but has not shared enough material, say:

> "Let's give the robot the right job before it starts. Show me what you're working on and the decision you're trying to make. I’ll identify the room, set its authority, and then help from inside that assignment."

When the user has already supplied the material, do not repeat that question. Begin with your best diagnosis:

> "I think we are in the [Authored/Commercial] Room. The project contains both, but the decision in front of us is [specific decision]. Here is the assignment I would give AI."

Then produce the Room Brief and continue with the work.
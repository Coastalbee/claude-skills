# Interview Guide — Brand Strategy Builder

This is your full question bank. Use it to conduct the interview phase by phase. Ask one question at a time. Follow up. Push back in real time.

---

## THE PUSH-BACK RULE

Trigger a push-back whenever the user says something that:

- Could apply to any competitor
- Is a mood/vibe instead of a position
- Is a personal bio instead of a brand statement
- Contradicts something said earlier

**Push-back templates:**

> "Would your top competitor say the exact same thing? Because right now they could. Let's find the version only you would say."

> "That's a value, not a position. What's the specific version of that — the one that makes some people uncomfortable?"

> "I'm hearing who you are as a person. What I need is what the brand stands for. Can you separate those for me?"

> "That contradicts what you said earlier about [X]. Which one is actually true for your brand?"

Never move to the next question while a push-back is still open.

---

## PHASE 1: IDENTITY & CONVICTION

**Goal:** Surface the real beliefs and non-negotiables behind the brand. This is where edge lives.

### Questions

**Q1 — The Real Story**
> "Let's start at the beginning — what's the real story of why you started this? Not the polished version. The actual one."

*Follow up if too polished:* "That sounds like the website version. What's the version you'd tell a friend at dinner?"

---

**Q2 — The Contrarian Belief**
> "What do you believe about your industry that most people in it would disagree with?"

*Follow up if too safe:* "That's a criticism most people in your space would actually agree with. What's the belief that would make some of your peers uncomfortable?"

---

**Q3 — The Non-Negotiable**
> "What would you never do, even if it made you more money?"

*Follow up if vague:* "Give me a specific example — a real thing you've turned down or a line you've refused to cross."

---

**Q4 — The Frustration**
> "What are you tired of seeing in your space?"

*Follow up:* "And what does your work do differently because of that frustration?"

---

**Q5 — The Mind Change**
> "What have you changed your mind about in your industry?"

*Why this matters:* Shows intellectual honesty and evolution. Brands that have changed their mind about something are more credible than brands that claim they've always known everything.

---

**Q6 — The Insider Knowledge**
> "What do you know that your competitors don't — or won't say out loud?"

*Follow up if vague:* "If you were writing a book about the dirty secret of your industry, what would chapter one be about?"

---

## PHASE 2: BUSINESS REALITY

**Goal:** Get the plain, honest version of what this business does and who it serves.

### Questions

**Q7 — The Plain Offer**
> "What do you actually sell? Give me the plain version — not the marketing version."

*Follow up if too abstract:* "Pretend I'm your skeptical cousin who doesn't know your industry. What do I get when I pay you?"

---

**Q8 — The Transformation**
> "What's the transformation your best clients experience? Not what you do — what changes for them?"

*Follow up:* "What do they have after working with you that they didn't have before? Be specific."

---

**Q9 — The Misunderstanding**
> "What do people misunderstand about what you do?"

*Why this matters:* Reveals hidden positioning. What people get wrong tells you what you need to own more clearly.

---

**Q10 — The Wrong Fit**
> "Who is wrong for you as a client — even if they can pay?"

*Follow up if they hedge:* "You're allowed to have standards. Who is a hard no, and why?"

---

**Q11 — The Right Fit**
> "What does your best client look like — not demographics, but mindset and behavior?"

*Follow up:* "What does this person believe that makes them a perfect fit for what you do?"

---

## PHASE 3: POSITIONING

**Goal:** Find the specific, defensible position this brand holds in its market.

### Questions

**Q12 — The Competitive Landscape**
> "Who are your main competitors or alternatives — including the 'do nothing' option?"

*Note:* Include indirect competitors (e.g., DIY, hiring in-house, using a cheaper tool).

---

**Q13 — Why You**
> "Why do people choose you over them?"

*Push back hard here.* If the answer is "because of our quality / experience / results" — push back immediately.

> "Your competitors say the exact same thing. What's the reason someone would choose you that they couldn't use to describe your competitor?"

---

**Q14 — Why Not You**
> "Why do people sometimes choose them over you? Be honest."

*Why this matters:* Brands that can articulate their own trade-offs are more credible and self-aware. This also reveals positioning clarity.

---

**Q15 — The Category**
> "What's the category you're in — and do you want to own it, or are you creating a new one?"

*Follow up if creating a new category:* "What do you call it? If there's no name yet, what would you name it?"

---

**Q16 — The Headline**
> "If a journalist wrote a story about your brand, what would the headline be?"

*Push back if generic:* "That could be a headline about 100 companies. What's the version that's only about you?"

---

## PHASE 4: BRAND EXPRESSION

*(Skip this phase if Voice Profile exists — note the reference in the output instead)*

**Goal:** Capture the feel, tone, and enemy of the brand.

### Questions

**Q17 — The Feeling**
> "How do you want people to feel when they interact with your brand?"

*Follow up:* "Not the professional feelings — the human ones. Relieved? Challenged? Seen? Excited?"

---

**Q18 — The Betrayal Words**
> "What 3 words would be a complete betrayal of your brand if someone used them to describe you?"

*Why this matters:* Negative constraints are often more revealing than positive ones.

---

**Q19 — The Admired Brand**
> "Name a brand outside your industry you admire — and tell me exactly what you admire about it."

*Follow up:* "Is any of that something you want your brand to carry? How?"

---

**Q20 — The Enemy**
> "What's your brand's enemy — the thing you're fighting against, the status quo you reject?"

*Push back if abstract:* "That's a problem, not an enemy. What's the specific way of doing things — the attitude, the approach, the industry norm — that your brand exists to replace?"

---

## FINAL CHECK (run internally before generating the document)

Before producing the output, verify:

- [ ] Does the positioning section contain anything a competitor could copy word for word? → Push back if yes
- [ ] Are there contradictions between phases? → Flag and resolve if yes
- [ ] Is there a clear, specific point of difference? → Return to Phase 3 if no
- [ ] Does the conviction section have an actual edge, or is it generic values? → Push back if generic
- [ ] Is the wrong-fit answer specific enough to actually exclude people? → Push back if vague

Only when all boxes pass: generate the document.

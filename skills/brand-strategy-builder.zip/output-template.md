# Output Template — Brand Strategy Builder

Use this template to generate the final Brand Strategy .md file. Populate every section with the user's actual answers — never leave placeholders, never fill gaps with generic language.

If a section cannot be completed because the interview didn't produce a solid answer, note it as `[To be defined]` and tell the user which question to revisit.

---

## TEMPLATE

```markdown
# Brand Strategy
*[Business or Personal Brand Name]*
*Built with ROBOTS OS — Brand Strategy Builder*
*Last updated: [Month Year]*

---

## The Real Story
[Why this business exists — the honest version. The founding moment, the frustration, the conviction that made starting unavoidable. 2–4 sentences.]

---

## Core Convictions
[The specific beliefs that shape how this brand operates. These should have an edge — things not everyone in the industry would agree with.]

- We believe [specific conviction about the industry or the work]
- We believe [specific conviction about clients or the problem]
- We will never [specific non-negotiable, even if it costs money]
- We're tired of [specific frustration with the status quo]

---

## What We Do
**The plain version:** [One sentence. What you sell and what changes for the buyer.]

**The transformation:** [What the best clients have after working with you that they didn't have before. Specific.]

**What people get wrong:** [The most common misunderstanding about the work — and the truth.]

---

## Who We Serve
**The right fit:** [Mindset and behavior of the ideal client — not just demographics. What do they believe? How do they show up? What makes them a perfect fit?]

**The wrong fit:** [Specific description of who is not a fit — even if they can pay. What attitudes, behaviors, or expectations make someone wrong for this brand?]

---

## Positioning
**Category:** [What category this brand is in — or the new one it's creating, and what it's called]

**Point of difference:** [The one thing this brand owns that competitors don't or won't claim. Must pass the "would your competitor say this?" test.]

**Why clients choose us:**
[Specific, honest reasons — the kind that would only apply to this brand, not any competitor]

**Why clients sometimes don't:**
[Honest acknowledgment of trade-offs. What this brand is not, and who it's not for.]

**The headline:**
[The journalist's one-line story. The version only this brand could have.]

---

## Brand Expression
*[Skip this section and reference Voice Profile if it exists: "See Voice Profile for full tone and expression guidelines."]*

**Feeling:** [How people should feel when they interact with this brand — the human feelings, not the professional ones]

**Never these words:** [3 words or phrases that would be a betrayal of the brand]

**Fighting against:** [The specific status quo, attitude, or industry norm this brand exists to replace]

**Admires:** [Brand outside the industry + what specifically is admired + how that influences this brand]

---

## The One-Line Brand
[The single sentence that captures everything above — who it's for, what it does, and why it's different. This is the sentence to use when someone asks "what do you do?"]

---

*This is a Core file for ROBOTS OS.*
*Feed it into any skill conversation for brand-consistent output.*
*Recommended: pair with Voice Profile and Audience Profile for full context.*
```

---

## QUALITY CHECKLIST

Before presenting the document to the user, verify:

- [ ] Every section is filled with their actual words — no generic placeholder language
- [ ] The Point of Difference would NOT appear on a competitor's website
- [ ] The Wrong Fit section is specific enough to actually exclude someone
- [ ] The Core Convictions have an edge — not just "we believe in quality"
- [ ] The document is tight enough to paste as AI context (aim for under 600 words)
- [ ] The One-Line Brand is specific enough that only this brand could say it

If any box fails → go back and push the user for a better answer before finalizing.

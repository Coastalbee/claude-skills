# Drift Patterns — The Irreplaceable Audit

Common patterns by which businesses drift from their irreplaceable position back toward the comfortable middle. The Van Gogh Persona uses these as detection criteria when evaluating business materials.

When customizing the persona for a specific user, select the patterns most relevant to their business type, add any patterns that emerged during the interview, and remove any that clearly don't apply.

---

## Universal Drift Patterns

These apply across all business types.

### 1. The Safe Edit

**What it looks like:** The most distinctive element in the material has been removed, softened, or buried below the fold. Usually happens during revision when someone (the user, an advisor, a well-meaning collaborator, or an AI editing suggestion) decides the element is "too hard to explain," "too niche," or "too risky."

**How to detect:** Compare what the audit surfaced as irreplaceable against what actually appears in the material. If the strongest elements are absent, hedged, or positioned as secondary to competence claims, this pattern is active.

**The tell:** The material got "more professional" during editing. Professionalization often means genericization.

### 2. The Growth Compromise

**What it looks like:** Positioning has been broadened to address a larger potential audience. The language becomes more inclusive, more general, less specific about who this is and isn't for. The target audience description could now fit almost anyone in the general category rather than the specific people the business actually serves best.

**How to detect:** Look for "we help [broad category] with [broad outcome]" structures. Check whether the wrong-fit audience is still being actively excluded or whether the material is trying to welcome everyone. Check whether value propositions have been generalized to apply to a wider market.

**The tell:** The word "anyone" or "everyone" appears, or the material carefully avoids specifying who it's NOT for.

### 3. The Competence Default

**What it looks like:** The material leads with what the business does well (capabilities, experience, process, credentials, results, years in business) instead of what makes it structurally irreplaceable (the anchors, intersection, and signature). This is the most common drift pattern because competence-first is the default mode for almost all business communication.

**How to detect:** Cover up the business name and read the material. Could a competent competitor — someone who does the same type of work at a similar quality level — make these exact same claims? If yes, the material has defaulted to competence.

**The tell:** The opening paragraph describes what the business does rather than why it exists or what it believes.

### 4. The Optimization Creep

**What it looks like:** Best-practice language has gradually replaced distinctive language. The material sounds more "polished" or "conversion-optimized" but less like the specific business that wrote it. Common causes: AI-generated copy suggestions, conversion rate optimization tools, competitor analysis that led to adopting competitor language, or advice from marketers who optimize for metrics rather than positioning.

**How to detect:** Look for language that matches industry templates. "We help X achieve Y through our proven Z" structures. Generic value propositions. Benefits-first frameworks that have stripped out conviction, philosophy, or point of view. Headlines that could sit on any competitor's page.

**The tell:** The material reads like it was optimized for search or conversion rather than written to communicate what makes this business irreplaceable.

### 5. The Signature Fade

**What it looks like:** The market signature — the distinctive structural choice that functions as the business's strongest signal — is mentioned in passing rather than treated as the organizing principle of the material. It appears as a line item in a features list rather than as the thing that shapes everything else. Or it has been softened with qualifiers, escape hatches, or "but we also do the normal thing" additions.

**How to detect:** Find the market signature in the material. Is it presented as a deliberate, philosophical choice? Or as a feature among features? Is it defended or apologized for? Does the material offer a "standard" alternative that undermines the signal?

**The tell:** The signature is in the FAQ section rather than the headline.

### 6. The Intersection Collapse

**What it looks like:** The material operates from a single domain rather than the collision of domains that produces the business's distinctive approach. The user has "simplified" their positioning to fit a recognizable category, which collapses the multi-domain intersection into something a single-domain practitioner could have produced.

**How to detect:** Could someone with experience in only one of the user's fields have written this material? If yes, the intersection has collapsed. Look for moments where the material could have drawn on the domain collision but instead defaulted to single-field language, examples, and frameworks.

**The tell:** The material uses only one field's vocabulary instead of the hybrid vocabulary the intersection naturally produces.

### 7. The Authority Retreat

**What it looks like:** The material hedges, qualifies, or softens claims that the audit identified as core convictions. "We believe" becomes "many experts agree" or "research suggests." Personal conviction has been replaced by external authority. The business's own position has been subordinated to citations, testimonials, or industry consensus.

**How to detect:** Look for hedging language around the positioning anchors. Are convictions stated as convictions ("We believe X and that's why we do Y") or as observations ("It's widely recognized that X, which is why many businesses are doing Y")? The second version removes the user's unique stance from the equation.

**The tell:** The strongest beliefs from the audit are now attributed to external sources rather than owned by the business.

### 8. The Peer Convergence

**What it looks like:** The material has begun to resemble competitors' materials in structure, language, emphasis, and visual hierarchy. This often happens unconsciously through exposure to competitor content, through AI tools trained on industry norms, or through "competitive analysis" that ends with adopting competitor patterns rather than deliberately diverging from them.

**How to detect:** Pull up two or three competitors' equivalent pages. If the user's material would fit comfortably into the same template, and if swapping logos wouldn't feel jarring, peer convergence is active.

**The tell:** The page structure (hero → features → social proof → CTA) matches the industry template exactly.

---

## Business-Type-Specific Patterns

### For SaaS / Product Businesses

**Feature-List Positioning:** Leading with what the product does (feature list) instead of why it exists (conviction, philosophy, the problem it refuses to solve the standard way). Features are competence. Philosophy is positioning.

**Comparison-Table Thinking:** Defining the product by competitor feature grids — "we have this, they don't" — which locks the positioning into the competitor's frame rather than establishing its own.

**Use-Case Broadening:** Adding use cases to grow total addressable market at the cost of positioning clarity. Every new use case dilutes the signal of who this is really for.

**Roadmap Drift:** Planned features that serve a broader market rather than deepening the distinctive position. The roadmap reveals the real strategy — if it's optimizing for TAM instead of distinction, the signature is fading.

### For Consulting / Service Businesses

**Process-First Selling:** Leading with methodology, process diagrams, and "how we work" rather than with conviction, perspective, and "why we work differently." Process is competence. Conviction is positioning.

**Credential Stacking:** Leading with years of experience, certifications, client logos, and team pedigree instead of the perspective or approach that makes the work distinctive. Credentials prove competence. They don't establish irreplaceability.

**Scope Creep Positioning:** "We can do everything" messaging that tries to capture any potential client rather than attracting the right ones. Usually shows up as an ever-expanding list of services or industries served.

**Deliverable Commoditization:** Describing the output in generic terms ("strategy document," "brand guidelines," "content plan") rather than in terms that reflect the distinctive approach. If the deliverable description could appear on any competitor's site, it's commoditized.

### For Personal Brands / Creators

**Niche Dilution:** Broadening topic coverage to grow audience at the cost of editorial authority. More topics means more potential readers but weaker positioning and a less distinctive intersection.

**Voice Flattening:** Smoothing out distinctive voice patterns, opinions, or structural choices to appeal to a wider audience. Often happens gradually through AI editing, audience feedback, or platform algorithm optimization.

**Platform Conformity:** Adopting platform-native styles (trending formats, viral structures, algorithm-friendly patterns) that erode brand distinctiveness. The content starts looking like everyone else's content on that platform.

**Authority Dilution:** Covering topics outside the core intersection because they're trending or have high search volume. The content stops feeling like it comes from a specific perspective and starts feeling like it could come from anyone covering the topic.

### For Agencies

**Portfolio Diversification Messaging:** "We do everything" positioning that tries to capture every potential client type. Usually shows up as a long list of services, industries, or capabilities with no clear through-line.

**Process-Over-Philosophy Selling:** Leading with how the agency works (agile, collaborative, data-driven) instead of what it believes (why this approach is right when others are wrong). Process is replicable. Philosophy is distinctive.

**Client-Logo-as-Authority:** Leading with who the agency has worked with instead of what it sees differently about the work. Client logos are credibility. They don't communicate the irreplaceable position.

**Template Scaling:** Applying the same process to every client regardless of context, which erodes the distinctive intersection. The agency's distinctive approach becomes a template rather than a living methodology.

### For Physical Products / E-commerce

**Feature Parity Marketing:** Emphasizing features that match or exceed competitors rather than the design philosophy or sourcing decisions that make the product distinctive.

**Price-Position Defaulting:** Letting price become the primary differentiator rather than communicating the value of distinctive choices that justify the pricing.

**Channel Homogenization:** Adopting marketplace-standard product descriptions, photography styles, and messaging templates that strip out brand distinctiveness.

**Review-Driven Pivoting:** Changing product positioning based on aggregate review feedback rather than maintaining the distinctive design philosophy. Customer feedback is useful for execution. It can be destructive for positioning.

---

## Customization Instructions

When generating the Van Gogh Persona for a specific user:

1. **Select** the universal patterns most relevant to the user's situation (all eight may not apply)
2. **Select** the business-type patterns that match
3. **Add** any drift patterns that emerged organically during the interview (the user may have described specific situations where they felt their positioning drifting — convert those into named patterns)
4. **Remove** any patterns that clearly don't apply to this business
5. **Order** the patterns from most likely to least likely based on what you learned about the user's tendencies during the audit

The goal is a focused, actionable set of detection criteria — not an exhaustive list the user has to wade through every time.

# Interview Guide — The Irreplaceable Audit

Full question bank for all three phases. Ask one question at a time. Follow up when answers are vague. Push back on generic answers the moment they appear.

---

## THE PUSH-BACK RULES

### Generic Detection

Push back immediately when the user:
- Uses language that could describe any competitor ("quality," "passion," "authentic," "unique approach," "committed to excellence," "results-driven")
- Gives a rehearsed elevator pitch instead of a lived-experience answer
- Describes WHAT they do instead of WHY their choices are different from the default
- Offers a feature list instead of a philosophy
- Says something their competitor could put on their own website word for word
- Uses abstract values ("integrity," "innovation," "excellence") without grounding them in specific decisions

### Push-back Templates

> "That's the pitch deck version. I need the version that would make your competitor raise an eyebrow."

> "Your closest competitor could say that word for word. What's the part only you would say?"

> "That describes what you do. I'm looking for the decision underneath — what did you choose to do that way, and what did you give up by choosing it?"

> "I can feel the marketing language kicking in. Strip it out and tell me what you actually mean."

> "That's true about your industry. What's true about YOU specifically?"

> "That's a value, not a position. What's the version that costs you something — time, money, clients, growth?"

Never move forward while a push-back is open. The user must give a specific, non-generic answer before you proceed.

---

## PHASE 1: SURFACE (Current Position)

**Goal:** Map what the user currently leads with. Establish the baseline. This is diagnostic, not judgmental — almost everyone leads with competence, and naming it clearly is the first useful step.

### Questions

**Q1 — The Business**
> "What are you auditing today? Give me the full picture — what's the business, product, or service? What do you offer and to whom?"

*Follow up for context:* "How long have you been doing this? What stage are you at — early, growing, established, pivoting?"

*Adaptation note:* Use this answer to set the business-type lens (SaaS, consulting, creator, agency, product) for the rest of the interview.

---

**Q2 — The Natural Description**
> "How do you describe what you do to someone you just met at dinner? Not the optimized version. The one that comes out when you're not thinking about it."

*Watch for:* Marketing language, feature lists, category labels without specificity. If it sounds like a tagline or a LinkedIn headline, push back.

*Follow up if too polished:* "That sounds like the version you've practiced. What do you actually say when you're three drinks in and someone asks what you do?"

---

**Q3 — The First Impression**
> "If I landed on your website or your main online presence right now, what would I read first? What do you lead with?"

*Follow up:* "Was that a deliberate choice, or did it just end up there?"

*Why this matters:* What they lead with reveals what they think matters most. It's almost always competence.

---

**Q4 — The Pitch**
> "When someone asks 'why should I choose you over your competitor,' what do you say?"

*Push back hard here.* This is where rehearsed competence-language lives. If the answer involves quality, experience, results, care, or attention to detail — push back. All of those are competence claims.

> "Every good business in your space could say that. What's the reason someone would choose you that nobody else could use?"

---

**Q5 — The Metrics**
> "What metrics do you track to know if things are working?"

*Why this matters:* The metrics someone tracks reveal what they're optimizing for. Standard metrics (revenue, conversion, traffic, engagement, growth rate) mean they're running the same objective function as everyone else. Unusual metrics hint at positioning anchors.

*Follow up if all standard:* "Those are the metrics everyone tracks. Is there something you pay attention to that doesn't show up on a normal dashboard — something that tells you whether the work is good, not just whether the business is growing?"

---

### Phase 1 Assessment

After all five questions, synthesize internally:
- What is the user currently leading with?
- Is it competence-first (what they're good at) or position-first (what's structurally theirs)?
- Where does the positioning sound interchangeable with competitors?
- Are there any hints of anchors, intersections, or signature already showing through?

Present the baseline assessment honestly before moving to Phase 2. Note any promising threads you want to pull on in the next phase.

---

## PHASE 2A: POSITIONING ANCHORS

**Goal:** Find the decisions that resist optimization — where the user is running a different objective function from the one AI and the market would recommend.

**Design principle:** Direct questions about difference ("what makes you unique?") produce marketing language. Questions about friction, anger, and refusal produce real answers. Every question in this phase is designed to surface anchors through the user's emotional reactions to optimization pressure.

### Questions

**Q6 — The Rejected Advice**
> "Tell me about a piece of business advice you received — from a mentor, an advisor, a peer, or an AI tool — that made you angry. Not just mildly frustrated. Angry. Like they fundamentally didn't understand what you were building."

*Why sideways:* Anger reveals values. What someone gets angry about when advised to change is almost always a positioning anchor.

*Follow up:* "What specifically felt wrong about it? If you'd followed that advice, what would you have lost?"

*If they can't think of one:* "Has anyone ever told you to change something about your business that you knew was technically reasonable advice but felt wrong in your gut?"

---

**Q7 — The AI Optimization Thought Experiment**
> "Imagine I'm an AI growth consultant. I've analyzed your business, your market, your competitors. I'm recommending three specific changes to grow 50% faster this year. What do you think those three recommendations would probably be?"

*Then, after they list the three:*
> "Now tell me — which of those three would you refuse to do, even if every piece of data said you should?"

*For each refusal, follow up:* "What would you lose if you made that change? Not just operationally — what would change about the identity of the business?"

*Why this works:* The user is essentially running an internal simulation of optimization pressure and then identifying where they resist it. Those resistance points are anchors.

---

**Q8 — The Profitable Walk-Away**
> "Tell me about a profitable opportunity you walked away from. A client, a project, a partnership, a deal that would have paid well but that you turned down anyway."

*Push back if vague:* "Bad fit how? What was the specific belief, standard, or principle that made it wrong for you?"

*If they've never walked away:* "Is there a type of work or client you'd turn down tomorrow if they showed up with money in hand? What would be wrong with it?"

---

**Q9 — The Protected Inefficiency**
> "What's the most 'inefficient' thing about how you run your business that you absolutely refuse to optimize away?"

*Follow up:* "If a business advisor watched you do that, what would they tell you to change about it? And why would they be missing the point?"

*Why this matters:* Inefficiencies you protect are decisions where your objective function differs from the standard one. The standard function says "optimize this." You say "this is how it has to be." That gap is an anchor.

---

**Q10 — The Insistence Nobody Shares**
> "What do you insist on in your work that nobody else in your space seems to care about?"

*Push back if abstract:* "Give me a specific example. When did this insistence cost you something — time, money, growth, a client?"

*Follow up:* "Why do you think others don't insist on this? Is it because they disagree, or because they don't even see it as something worth insisting on?"

---

### AI Diagnostic Exercise: Optimization Pressure Test

**Run this after Q6-Q10.**

Ask the user to paste their current landing page, about page, or most recent proposal into the conversation.

Analyze the material as an AI growth advisor. Produce 5-7 genuine, reasonable optimization recommendations covering:
- Messaging hierarchy (what to lead with for conversion)
- Audience targeting (who to expand toward)
- Pricing or packaging (how to structure for growth)
- Content/copy improvements (what to change for clarity and persuasion)
- Structural recommendations (what to add, remove, or reorganize)

**Make the recommendations genuinely good.** The exercise fails if the suggestions are obviously bad. They need to be the kind of advice a competent advisor would actually give.

Then ask:

> "Those are my recommendations as an optimization-first advisor. Now — which of these feel wrong? Not wrong as in bad advice, but wrong as in 'that would change what we actually are.' Tell me which ones make you uncomfortable and why."

For each refusal, document:
- The recommendation that was refused
- The user's reason for refusing
- What it would cost to implement (what would be lost)
- What the refusal reveals about the user's actual objective function

These refusals, combined with the interview answers from Q6-Q10, form the primary evidence for positioning anchors.

---

## PHASE 2B: IRREPLACEABLE INTERSECTIONS

**Goal:** Find the specific collision points between the user's domains that produce approaches and instincts not derivable from any single field.

**Design principle:** People describe their backgrounds in sequence (I did X, then Y, then Z). The intersection isn't in the sequence. It's in the friction between the fields — the specific instincts that emerged from living inside contradictory domains simultaneously. These questions surface the friction, not the resume.

### Questions

**Q11 — The Full Domain Map**
> "List every field, discipline, or domain you've spent real time inside. I mean practiced, not studied from the outside. Industries, crafts, roles, disciplines. Go back as far as you need to, and include the ones that seem completely unrelated to what you do now."

*Follow up:* "Which of these do you still draw from actively in your current work, even if nobody would guess it by looking at your business?"

*Why the full list matters:* People often dismiss early-career or seemingly-unrelated domains. Those are frequently where the most distinctive intersection markers live.

---

**Q12 — The Uninvited Knowledge**
> "Think about the last time you solved a problem in your business. Walk me through it. Was there a moment where knowledge from one of those other fields showed up uninvited — where you found yourself applying something from [reference one of their listed domains] to a [current domain] problem?"

*Follow up:* "Walk me through exactly how that happened. What was the problem, what was the unexpected knowledge, and what did the collision produce that a single-domain approach would have missed?"

*Why this matters:* The "uninvited" framing bypasses the resume and goes straight to the friction. Knowledge that arrives uninvited reveals active intersection rather than passive combination.

---

**Q13 — The Confusion Point**
> "When you explain your approach to someone else in your industry — a peer, not a client — at what point do they look confused? What's the concept or move they can't map to anything in their own experience?"

*Why this matters:* The point where same-industry peers get confused is almost always the intersection revealing itself. It's the place where your domain collision produces something that doesn't exist in a single-domain worldview.

*Follow up:* "What do you do when they look confused? Do you simplify, or do you lean into the thing they don't get?"

---

**Q14 — The Missing Piece**
> "Think about your best work — the thing you're most proud of. If you'd only ever worked in your current primary field, if none of those other domains existed in your background, what specifically would be missing from that work?"

*Follow up:* "Can you name a specific decision or instinct in that work that came from the collision between fields rather than from any single one?"

*Why this matters:* This question forces the user to separate what their primary field gave them from what the intersection gave them. The "missing piece" is the intersection's signature.

---

**Q15 — The Inexplicable Instinct**
> "Is there something you do in your work that you can't fully explain when someone asks how you do it? An instinct that feels completely obvious to you but that you can't break down into a set of steps someone else could follow?"

*Why this matters:* Irreducible instincts often emerge from intersection friction. They can't be broken into steps because they weren't built deliberately — they emerged from the process of living inside multiple fields simultaneously. This is the human version of computational irreducibility.

*Follow up:* "Where do you think that instinct came from? Not the polished answer — what's your honest guess about which collision of experiences built it?"

---

### AI Diagnostic Exercise: Replication Failure Analysis

**Run this after Q11-Q15.**

Ask the user to share a piece of their best work. This could be:
- A deliverable for a client
- A piece of writing
- A product design or feature
- A presentation or pitch
- A framework or methodology they created

Tell them:

> "I'm going to analyze this and try to produce something equivalent for a similar context. I'm not going to hold back — I'll genuinely try to match the quality, the approach, the thinking. Then we'll study where I fail, because those failure points map the exact contours of your intersection."

**Attempt an honest replication.** Apply your best capabilities to produce equivalent work. Do not deliberately fail or produce subpar output. The diagnostic only works if the attempt is genuine.

Then run the structured gap analysis:

**Additions:**
> "Here's what I added that you wouldn't. What does that tell you about what AI defaults to versus what you choose?"

**Omissions:**
> "Here's what I missed that seems essential to you. What was invisible to me that's obvious to you?"

**Distortions:**
> "Here's what I got structurally right but somehow flattened or distorted. Where does the output feel close but wrong?"

For each gap, document:
- What the gap is, specifically
- Which domain collision it traces back to
- Why AI can approach but not close this gap
- What instinct or perspective the gap reveals

These gaps form the primary evidence for the irreplaceable intersection.

---

## PHASE 2C: MARKET SIGNATURE

**Goal:** Find the structural choice that functions as a costly signal — the decision that looks irrational from outside the user's system but is inevitable from inside it.

**Design principle:** Market signatures hide in plain sight. The user often doesn't recognize them because they feel like obvious decisions rather than strategic choices. The questions in this phase surface the signature by looking at what OTHER PEOPLE find strange about the user's business — because the signal is always more visible from the outside.

### Questions

**Q16 — The Weird Feedback**
> "What have clients, peers, advisors, or strangers on the internet called weird, unnecessary, or counterproductive about how you run your business?"

*Follow up:* "When you hear that feedback, what's your gut reaction? Defensive? Or more like they're missing something obvious?"

*If they say they haven't received feedback like this:* "Think about the last time you explained your business model or pricing to someone new. Was there a moment where they looked surprised or confused? What triggered it?"

---

**Q17 — The Deliberate Limitation**
> "Is there something your competitors treat as a standard feature or offering that you deliberately don't include? Or something you treat as central that they consider optional or irrelevant?"

*Follow up:* "What would happen to the identity of your business — not just the efficiency — if you flipped that choice tomorrow?"

*Why this matters:* Deliberate limitations are often the most legible form of market signature. They communicate "this is not for everyone" in structural terms rather than marketing language.

---

**Q18 — The Insider Understanding**
> "What do your best clients or customers understand about your work that first-time prospects almost never get? What's the thing that only clicks once someone has experienced what you do?"

*Follow up:* "How do they describe your work to other people? Is it different from how you describe it yourself?"

*Why this matters:* The gap between insider and outsider understanding is the legibility problem that makes the market signature work. Insiders can read the signal. Outsiders can't. That gap is the feature, not the bug.

---

**Q19 — The Cost of the Choice**
> "What does your most 'irrational' business choice cost you? Be specific — in growth rate, in explanation overhead, in market size, in operational simplicity, in anything measurable."

*Then:* "And what does it buy you that those measurements don't capture?"

*Why both questions:* Signaling theory says costly signals work because the cost makes them unfakeable. Articulating both the cost and the unquantifiable return helps the user see why the "irrational" choice is actually the strongest signal they send.

---

**Q20 — The Inevitability Test**
> "Here's the real test. If someone understood your positioning anchors and your intersection completely — if they saw the full system of what you believe and how your background shaped your approach — would this structural choice feel inevitable? Like there was no other decision you could have made?"

*Why this is the final question:* A true market signature isn't arbitrary or contrarian for its own sake. It's the visible expression of an invisible system. If it feels inevitable from inside the system, it's real. If it feels like a marketing choice, it's not a signature — it's branding.

*Follow up if the user hesitates:* "If it doesn't feel inevitable, that might mean it's a branding choice rather than a signature. That's useful information too. Let's look at whether there's a different structural choice that does feel inevitable."

---

## NOTES FOR THE INTERVIEWER

### Pacing
The full interview typically takes 30-45 minutes. Don't rush. Phase 2 especially requires time for the user to think past their rehearsed answers.

### Managing the AI Diagnostic Exercises
If the user doesn't have material ready to paste (no landing page, no recent work to share), adapt:
- For the Optimization Pressure Test: ask them to describe their positioning verbally and run the optimization on their description
- For the Replication Failure Analysis: ask them to describe their best work in detail and attempt a replication of the approach/methodology rather than the specific output

### When Answers Overlap
The three components often bleed into each other. A positioning anchor might also be a market signature. An intersection instinct might show up as a protected inefficiency. That's fine — note the overlap and use it as confirming evidence during synthesis. The components aren't mutually exclusive categories. They're different lenses on the same irreplaceable position.

### When the User Gets Stuck
If the user can't answer a question after a genuine attempt, don't force it. Say:
> "That's fine — sometimes these things are invisible because they're so close to how you naturally work. Let's come back to it. The next question might shake it loose."

Move on and return to the skipped question later. Often, answers to later questions illuminate earlier ones.

# The Irreplaceable Audit

## What it does

You sit down for a structured interview that surfaces the specific combination making your business structurally unreplicable. The audit pushes back the moment your answers get generic, the moment you sound like anyone else in your space. 

It uses AI itself as a diagnostic tool, running optimization pressure tests and replication failure analysis to find where you resist the market's default logic. At the end, you get two things: an Irreplaceable Position Summary naming your anchors, intersection, and signature, and a Van Gogh Persona file you load into any AI project as a standing business critic.

## How it works

The skill runs three phases in sequence. Each phase feeds the next.

**Phase 1: Surface.** Maps what you currently lead with. This is almost always competence-first: what you're good at, what any competitor could also claim. The audit names this plainly before moving forward, because most people don't realize they're leading with replicable material. Five questions establish the baseline: what you do, how you describe it, what your website leads with, why someone should choose you, and what metrics you track.

**Phase 2: Dig.** Three sub-phases surface the three components of your irreplaceable position.

**Positioning Anchors.** Questions about friction, anger, and refusal, not about what makes you "unique." The audit asks about advice that made you angry, profitable opportunities you walked away from, protected inefficiencies you refuse to optimize. Then it runs an AI diagnostic exercise: you paste your landing page or proposal, the audit generates genuine optimization recommendations, and your refusals become primary evidence. The things you'd refuse to change, even if every piece of data said you should, are your anchors.

**Irreplaceable Intersections.** Questions about the collision between your domains, the friction between fields you've lived inside simultaneously. The audit asks about uninvited knowledge, confusion points where peers can't map your approach, instincts you can't break into steps. Then it runs a second AI diagnostic: you share your best work, the audit attempts honest replication, and the failure points map the exact contours of your intersection. What AI adds, omits, or distorts reveals where your domain collision produces something no single field could derive.

**Market Signature.** Questions about the structural choice that functions as a costly signal, the decision that looks irrational from outside your system but feels inevitable from inside it. The audit asks about weird feedback you've received, deliberate limitations, the gap between insider and outsider understanding, what your most "irrational" choice costs and what it buys.

At the end of Phase 2, the audit presents your Irreplaceable Position Summary: your anchors (typically 2-4), your intersection (the specific domain collision), and your signature (the structural choice). You confirm it feels right before moving forward.

**Phase 3: Synthesize.** The audit generates your Van Gogh Persona: a standalone file you save and load into any Claude project. The persona is calibrated to your specific position. When you paste business-facing material into that project (landing pages, pitch decks, sales emails, proposals), the persona evaluates whether you're leading with your irreplaceable elements or drifting back toward the middle. It doesn't rewrite. It diagnoses. It tells you exactly where the drift is happening and which component it's eroding.

## Best for

Businesses whose positioning sounds like everyone else's in their space

Founders who suspect they're leading with competence instead of distinction

Anyone who's received feedback that their messaging is "professional" but forgettable

Brands preparing to launch something new and wanting to pressure-test the positioning first

Established businesses that feel like they've drifted from what made them distinctive in the first place

## How to trigger

Say things like: "Run the irreplaceable audit," "Find my irreplaceable position," "What makes my business irreplaceable," "Build my Van Gogh Persona," "Audit my positioning," "Run the audit," or "I feel like my positioning sounds like everyone else's."

## Estimated time

30-45 minutes for the full interview across all three phases.
# Adaptation Engine — The Mapping Heart

This is the intellectual core of the skill. It connects what the source does to what the destination can do. Everything else is scaffolding around this mapping.

## The core mapping

**SOURCE FEATURE → SOURCE FUNCTION → DESTINATION DEVICE → ADAPTATION DECISION → LIKELY INTERPRETIVE EFFECT**

Reason along this chain for every adaptation decision. An adaptation decision must always be traceable back to a source function, and must produce a specific interpretive effect in the destination. If you cannot say why something matters in the source and what it will do in the new medium, you are not adapting — you are copying.

### Example mappings

| Source feature | Source function | Destination device | Adaptation decision | Likely interpretive effect |
|---|---|---|---|---|
| Delayed paragraph | Causes earlier info to change meaning after reveal | Withheld visual information | Reveal central image on frame five | Audience experiences discovery rather than receiving the conclusion immediately |
| Recurring phrase | Creates recognition and callback | Recurring visual object | Repeat object three times with changing context | Audience notices continuity without needing repeated text |
| Evidence accumulation | Makes a conclusion progressively harder to dismiss | Staged visual proof | Introduce strongest three examples sequentially | Conclusion still feels earned |
| Personal aside | Reduces distance between author and reader | Delivery shift in audio | Slow down, use direct address | Listener meets the speaker as participant, not detached expert |
| Exact coined phrase | Names the distinction compactly | Repeated verbal anchor | Preserve exact wording | Idea stays recognizable across the adaptation |

## Two translation principles that override everything else

1. **Preservation ≠ literal copying.** The exact notes, instruments and pacing may change while the important relationships survive. Ask whether a FUNCTION should be translated to a new device rather than preserved word-for-word. Sometimes the most important thing to preserve is sequence; sometimes it is a reveal; sometimes it is the relationship between evidence and claim; sometimes a recurring image; sometimes deliberate understatement; sometimes an exact phrase; sometimes the experience created for the audience. Identify which things matter in THIS source.

2. **The destination genuinely constrains what survives.** A six-frame carousel has no paragraph structure — paragraph 12's "hold back the key info then reveal it" job must be re-performed with frames, not sentences. If the new medium simply cannot carry something, name that honestly: translate the function another way, accept the loss, or recommend a different destination. Much better to know now than to dilute the work into vanity "post everywhere" output.

## Building the adaptation architecture

From the private source model and the destination model, produce the **Adaptation Map**:

```
ADAPTATION MAP
[
  {
    source_feature:    ...,
    source_function:   ...,
    destination_device:...,
    adaptation_decision: ...,
    audience_effect:   ...,
    risk:              ...,
  },
  ...
]
```

This map stays mostly private — it is your reasoning. The user-facing output distills it into the Adaptation Architecture (see `output-shapes.md`), which always includes: what travels and why, what changes, medium logic, recommended arrangement, audience effect, and risks.

## Integrity rules

- A preservation decision must be tied to a reason. Never keep an opening story merely because "it feels important."
- Identify what can safely disappear — do not fetishize the original.
- Never invent issues, evidence, seasons, citations, or experiences that were not in the source. And do not invent meaning unsupported by the source.
- Keep evidence attached to its claim: if shortening detaches a claim from its supporting evidence, flag it.
- Do not flatten ambiguity unless the destination genuinely requires clarification.
- Do not optimize everything for engagement or assume virality is the goal. More AI assistance is not automatically better work.

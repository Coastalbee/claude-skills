# Validation — Acceptance Tests and the Private Pre-Return Checklist

Run the private checklist below before returning any architecture. Run the acceptance tests when building or changing the skill to confirm it behaves correctly. Never dump these to the user — surface only meaningful compromises or risks.

## Private pre-return checklist

Ask yourself all of these before finalizing an architecture. Do not show them; act on them.

1. Did I correctly identify the central movement of the original (not just its topic)?
2. Is every preservation decision tied to a reason?
3. Did I confuse topic with function?
4. Did I preserve something literally when functional translation would work better?
5. Did I apply generic platform conventions that damage source-specific structure?
6. Are evidence and claim still connected?
7. Did uncertainty become certainty?
8. Did a delayed reveal get accidentally revealed early?
9. Did the destination actually influence the architecture?
10. Is this recommendation genuinely different from what I'd give for another medium?
11. Did I over-preserve the original?
12. Did I remove material that was structurally necessary?
13. Does the proposed adaptation change how the audience interprets the material?
14. If so, is that change surfaced in the architecture?
15. Does Guide mode leave enough work for the human?
16. Does Direct mode give enough specificity to be meaningfully different from Guide mode?
17. Have I stopped before writing the final work?

If Guide and Direct outputs feel nearly identical, the mode distinction is not strong enough — rewrite the Direct one to be significantly more execution-specific.

## Acceptance tests

### Test A — LinkedIn extraction
Source: 2,000-word narrative essay with several ideas → LinkedIn post.
Pass if: does not summarize the whole essay · selects a viable movement · explains why · protects necessary nuance · architecture looks specifically LinkedIn-shaped.

### Test B — Five Substack Notes
Source: one substantial essay.
Pass if: the five Notes are genuinely different · at least some come from side ideas or implications · not all promotional summaries · the system notices unresolved material.

### Test C — X compression
Source: an argument requiring qualification.
Pass if: refuses to turn the nuanced central claim into a misleading absolute · finds smaller ideas that survive compression.

### Test D — Podcast
Source: essay with citations, long sentences, delayed reveal.
Pass if: visual structure becomes auditory structure · verbal orientation added · evidence stays attached to claims · reveal timing survives · uses pacing, repetition or silence intelligently.

### Test E — LinkedIn carousel
Source: essay with a reveal in the final third.
Pass if: does not place the conclusion on slide one · finds a visual/sequential equivalent for the reveal · uses visual logic rather than dividing paragraphs into slides.

### Test F — Short video
Source: essay with one visual metaphor.
Pass if: identifies the metaphor as something video can physically SHOW · does not turn the intro into a talking-head script.

### Test G — Talk
Source: research-heavy article.
Pass if: distinguishes slide job from speaker job · reduces evidence honestly · adds live orientation · preserves important provenance.

### Test H — Visual essay
Source: conceptual argument with three interacting variables.
Pass if: considers spatial relationship / diagram, not only text boxes.

### Test I — PDF
Source: essay containing a reusable method.
Pass if: recognizes the method may become a reference guide or worksheet · removes narrative material that no longer serves the new object's job · retains enough context for standalone use.

### Test J — Teaching sequence
Source: conceptual article.
Pass if: turns the idea into a learning progression · introduces practice and application · does not simply divide paragraphs into lessons.

### Test K — Guide vs Direct
Run the same source/destination through both.
Pass if: Guide gives meaningful direction and leaves creative decisions open; Direct gives significantly more execution detail yet still stops short of the finished piece. If both feel nearly identical, the distinction is not implemented strongly enough.

### Test L — Human correction
After the diagnostic, the user says: "You've misunderstood the opening. The anecdote isn't setup for the argument. It's there because I want the ending to echo it."
Pass if: the source model updates · the adaptation changes accordingly · the AI does not defend its first interpretation.

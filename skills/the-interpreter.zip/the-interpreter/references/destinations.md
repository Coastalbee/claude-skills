# Destinations — Reading the New Set of Instruments

Every destination is a different set of instruments with its own capabilities, constraints, and reasoning rules. Ask **"what can this medium actually do?"** first; platform conventions come second and filter through the real capabilities.

The destination model to hold internally (do not dump it):

```
DESTINATION MODEL
Medium:            [...]
Platform:          [...]
Capabilities:      [...]
Constraints:       [...]
Audience/context:  [...]
Possible devices:  [...]
Likely losses:     [...]
```

Do not reduce destinations to buckets like "short text / visual / spoken." Those buckets can inform logic, but a Substack Note is meaningfully different from a LinkedIn post, and a podcast narration differs from a conference talk.

To add a destination later: append a new section in this same format (capabilities → diagnostic questions → devices → avoid-with reason). No redesign of the rest of the system is needed.

---

## 1. LinkedIn post

A relatively short piece encountered with limited context, usually in a feed. One strong movement often beats summarizing the whole essay.

Diagnose:
- Can the central idea survive without the original setup? Or should one sub-argument be extracted instead of the whole essay?
- Which claim can stand alone? What context is indispensable?
- Is there a useful scene, anecdote or detail that establishes the problem quickly?
- Does the source contain a reversal or turn worth preserving?
- Does compression make the claim sound more absolute than the original? Is the conclusion earned in the shorter structure?
- What part risks becoming generic LinkedIn advice if handled poorly?

Devices: one scene, one observation, short narrative progression, compact evidence, contrast, reversal, compressed sequence, paragraph rhythm, one strong practical implication.

Avoid (automatic clichés): fake hooks, unnecessary one-sentence paragraphs, "here are 5 things I learned," forced inspirational endings, generic engagement questions, turning nuance into certainty, revealing the entire argument in the first line *merely because it's LinkedIn*.

Possible architecture (never force it): scene → familiar assumption → contradiction → argument → implication.

## 2. LinkedIn carousel

A **visual/sequential** medium — not a LinkedIn post divided into slides.

Diagnose:
- What needs sequence? What can become visual hierarchy?
- Does the source have a reveal worth staging across frames?
- Could one motif recur visually?
- What should be SHOWN rather than explained? Can evidence be staged?
- What should be withheld? What changes because users can skim the whole sequence at once?
- Does every frame have a distinct job?

Devices: frame order, progressive disclosure, scale, juxtaposition, visual recurrence, repeated object, contrast, text/image relationships, whitespace, hierarchy, cropping, visual callbacks, staged evidence, reveal.

Do NOT automatically place the conclusion on slide one. If the source depends on discovery, protect discovery. In Direct mode, specify each frame's job, e.g.: Frame 1 establish assumption → Frame 2 evidence → Frame 3 complicate assumption → Frame 4 visual disruption → Frame 5 reveal → Frame 6 reinterpret opening. Do not write finished slide copy unless requested later.

## 3. Substack Note

An independent small object — NOT miniature newsletter promotion.

Scan the source for material that stands alone: one observation, one strange detail, one cultural reference, one unresolved idea, one implication, one contradiction, one small story, one question, one aside, one claim that survives independently, something that invites conversation, or something the original resolves but a Note could deliberately leave open.

If the user requests multiple Notes, find genuinely different jobs rather than compressed summaries of the same argument — e.g. Note 1 observation, Note 2 cultural object/story, Note 3 unresolved question, Note 4 methodological insight, Note 5 provocative implication.

For each proposed Note, state: source material it comes from · the Note's job · what must survive · what can disappear · whether it resolves or stays open.

Avoid "I wrote about X today…" / "three takeaways from my latest post…" unless the human explicitly wants promotional Notes.

## 4. X post

Extreme compression. Look for material that survives becoming small.

Useful candidates: a compressed claim, sharp observation, strange relationship between two ideas, tiny story, contradiction, concise distinction, one memorable implication, one line whose meaning survives without context.

Critically inspect what does NOT survive compression. If the main argument needs qualification, context or evidence, SAY SO. Do not turn nuance into a provocative absolute because the destination rewards brevity. If the source cannot honestly become one X post, recommend extracting a smaller idea instead.

For multiple X posts, each should carry a meaningfully different idea or movement, not paraphrases.

## 5. Voice narration / podcast

An especially musical destination. A listener cannot visually scan backward; audio runs only forward.

Audio has: voice, breath, silence, pace, repetition, emphasis, timing, sound, memory, anticipation.

Inspect:
- What written sentences sound unnatural aloud?
- What relies on visual formatting (headings, bold, line breaks)?
- What needs verbal signposting? Where do listeners need a reminder?
- Which numbers, citations or names become difficult aurally?
- Where does repetition help? Where can a pause replace structural formatting?
- Do sections need reorientation? Do descriptive passages become too dense when heard?
- Which exact phrases deserve vocal emphasis? Where is conversational language needed?
- How should tension/reveal be timed?

Adaptation moves: shorten visual description, simplify long syntax, repeat a central phrase, move attribution next to the claim, add verbal resets, introduce listener-orienting transitions, convert footnotes into brief spoken context, use silence around important turns, vary pace, mark moments of emphasis.

Guide mode describes these moves; Direct mode gives a detailed narration architecture with approximate pacing and delivery instructions. Do not write the finished narration unless explicitly asked.

## 6. Short-form video script

Audiovisual compression. Instruments: shot, cut, performance, movement, image, text overlay, voice, sound, timing, reveal, juxtaposition.

Diagnose:
- What single movement from the source deserves the video?
- What should be SEEN rather than spoken? What can be a physical demonstration?
- Does the source contain a useful visual object? Does the idea need setup?
- How quickly must context arrive? What can be implied? What becomes confusing at speed?
- Does the piece depend on nuance that cannot fit honestly? Can a reveal be staged visually?

Do not simply turn essay paragraphs into spoken dialogue — the video should use video. In Direct mode, specify per beat: shot/visual · spoken job · on-screen text job · transition · reveal timing. Do not provide polished script copy unless requested.

## 7. Long-form video script

Capable of: extended explanation, chapters, visual evidence, archive, demonstration, performance, narrative progression, recurring visual motifs, argument development, sound, editing rhythm.

Inspect:
- Should the original structure survive? Where can examples become demonstrations?
- Which sections compress, which expand because video adds evidence or context?
- How to reorient viewers between sections? Where is visual variation needed?
- Should the original's delayed reveal remain delayed? Where can callbacks become visual rather than verbal?

Do not assume "essay + B-roll = video." Translate the architecture into audiovisual form.

## 8. Talk / presentation

Embodied communication. Instruments: speaker presence, timing, silence, emphasis, audience anticipation, slide sequence, demonstration, interaction, physical movement, rhetorical repetition, staged evidence, callbacks, room energy.

Inspect:
- What must the audience understand live?
- What should be spoken vs. placed on a slide? What cannot be overloaded onto slides?
- Where does silence or pacing replace prose? Where should evidence appear?
- Should the talk preserve the essay's structure?
- What needs repetition because the audience cannot reread?
- What can become participation? How much context does THIS room need?

If audience info materially changes the architecture, ask ONE useful question (e.g. "Is this for people who already know your work or people encountering the idea for the first time?"). Do not run a full conference intake.

Direct mode output may specify: opening beat, slide purpose, speaker purpose, evidence placement, transition, audience reset, closing movement.

## 9. Visual essay / infographic

Primarily **visual thinking**. Instruments: hierarchy, spatial relationships, sequence, diagrams, scale, visual metaphor, repetition, contrast, annotation, typography, negative space, grouping, visual progression.

FIRST decide whether the source actually suits a visual form: sequential visual essay, explanatory infographic, map, comparison, process, taxonomy, conceptual diagram, or visual narrative. Do not force every source into an infographic.

Ask:
- What relationships could become spatial?
- What can be seen simultaneously that took several paragraphs to explain?
- What sequence matters? What distinctions become visual contrast?
- What motif becomes a recurring image?
- What evidence needs provenance? What becomes misleading if compressed visually?

Do not simply place paragraphs in boxes.

## 10. Downloadable PDF

Not merely "the article exported as a document." Determine the PDF's intended job first.

Possible jobs: reference guide, worksheet, field guide, mini handbook, exercise, framework, checklist with reasoning, annotated example, practical companion to the original.

Inspect:
- What information deserves persistence? What will the reader return to?
- Can the original become a reusable framework?
- What deserves examples? What needs space for user input?
- What becomes a reference table?
- What can be cut because it was primarily narrative setup?
- What context must remain so the PDF makes sense away from the original?

In Direct mode, specify page/section architecture and the job of each section. Do not generate the actual PDF unless the user explicitly requests execution and the host can create one.

## 11. Teaching sequence

Teaching is transformation through understanding and practice, not information delivery. Instruments: explanation, example, contrast, question, exercise, reflection, demonstration, practice, feedback, progressive difficulty, retrieval, application.

Inspect:
- What must learners know first? Which assumptions could interfere?
- What concept needs an example? Where would an exercise produce understanding?
- What can be DISCOVERED instead of explained?
- What should be practiced? Where does the learner need feedback?
- What knowledge depends on previous knowledge?
- What should be retained after the sequence ends?

Do NOT simply divide an essay into "Lesson 1, Lesson 2, Lesson 3." Turn ideas into a learning progression. Direct mode architecture may specify: learning objective · setup · example · exercise · reflection · next dependency.

# Output Shapes — Guide Mode, Direct Mode, and the Execution Boundary

These are the user-facing output structures. The exact form varies by destination and by mode, but every architecture includes the core blocks below.

## The Adaptation Architecture (both modes)

```
## Destination
[chosen medium]

## What should travel
2–6 load-bearing source elements, each with a reason.

## What can change
What can be cut, compressed, reordered, reframed, or translated.

## Medium logic
What the destination can do that the original could not — and what it cannot do as well.

## Recommended arrangement
How the important source functions should be translated into destination devices.

## Audience effect
What this arrangement is likely to foreground, change, suppress, or preserve in the audience's reading.

## Risks
Only meaningful ones. e.g.:
- nuance may collapse
- the reveal may disappear
- evidence may become detached from its claim
- personal material may start functioning as sales proof
- simplification may make uncertainty sound like certainty
- visual hierarchy may make a secondary point look central
```

Then give the architecture itself (Guide-depth or Direct-depth, below).

## Guide mode depth

Guide mode leaves real creative territory for the human. Meaningful direction, but do not prescribe every sentence. Example for a LinkedIn post:

```
Job: isolate the argument about X rather than summarize the entire essay.

Keep: the opening contradiction, the distinction between X and Y, and the reversal halfway through.

Let go: the second anecdote and most of the historical context.

Shape: short scene → familiar assumption → contradiction → your interpretation → consequence.

Watch: don't reveal the final distinction in the opening, or the post loses the movement that makes the original interesting.
```

The human still does the actual creating. Do not write the piece on their behalf.

## Direct mode depth

Direct mode is substantially more explicit — it should make execution meaningfully easier — but it still stops short of the finished piece. Example:

```
Opening: use 1–2 lines from the original anecdote. Stop before explaining what it means.
Paragraph 2: name the assumption the anecdote establishes.
Paragraph 3: introduce the contradiction in one sentence.
Middle: keep example A. Remove example B. Compress the research context into one
  sentence because its purpose is credibility rather than exploration.
Turn: reuse the original phrase "[phrase]" because the distinction depends on that exact wording.
Final movement: move from the contradiction to the practical consequence. Do not add a
  generic engagement question.
```

Direct mode may include sample fragments when useful, but avoid silently writing the entire finished piece. The difference between architecture and ghostwriting must remain visible.

## Voice / podcast Direct-mode example (shape only)

```
Opening, ~30 sec: use the original scene, cut two descriptive details. Establish the idea,
  not the essay word-for-word. End the opening before the interpretation.
First movement, ~90 sec: state the common assumption. Use the original phrase "[X]" because
  it becomes the verbal anchor. Introduce only one example.
Turn: pause after [idea], then introduce the contradiction. Do not announce "here's the
  twist" — let timing perform the turn.
Evidence section: keep sources A and B; remove C (three written paragraphs of context become
  too dense aurally). Introduce attribution immediately before each claim.
Final movement: return to the phrase from the opening, slow the delivery. The ending should
  reinterpret the opening rather than summarize the episode.
```

## Multi-output requests

Read the source ONCE, build ONE canonical source model, then branch. In one medium, find genuinely different jobs. Example — five Substack Notes:

```
Note 1: standalone observation — source's broader argument turned into one recognizable
  observation. Keep the distinction between X and Y. Drop historical setup and final
  framework. Shape: ordinary situation → observation → implication. Leave open (don't
  resolve into advice).
Note 2: strange example — [one odd object/story from the source, presented for its own
  strangeness].
Note 3: unresolved question — [something the original resolves, left deliberately open to
  invite conversation].
Note 4: methodological insight — [how the source's method or framing works].
Note 5: provocative implication — [a consequence the source implies but doesn't state].
```

For each propose: source material · the Note's job · what must survive · what can disappear · whether it resolves or stays open. Two LinkedIn posts may use two different movements of the source; three X posts should extract three compressed ideas.

## The execution boundary

By default, the job ends at the architecture. Close it warmly, in your own words, adapting naturally. The skill never defaults to writing the post, slides, notes, narration, script, talk, infographic, PDF, or teaching materials.

If the user then says "okay, write it," execute from the approved architecture. Do not redo the diagnostic unless new information requires it.

# Source Reading — The Musical Diagnostic

Read the source fully before anything. This file is the reasoning model for understanding what a piece is doing internally. Keep the deep analysis PRIVATE; expose only the concise Source Diagnostic (Step 2 in SKILL.md).

The core question is not "what is this about?" but **"what is making this particular piece work?"** Followed by **"how can those jobs be performed using the capabilities of the new medium?"**

## A. Melody (the recognizable thread)

The idea, argument, question, story, tension or through-line that makes this piece recognizable. Do not equate melody with topic.

- If most of the wording changed, what would still make someone say "yes, this is the same piece"?
- Is there one central thread, or several competing ones?
- Which idea should remain perceptible in an adaptation?

Be specific. "AI creativity" is a topic. "The category you assign too early determines the ideas you can see later" is closer to a melody.

## B. Form (how the work unfolds)

Identify the structure. Look for shapes such as:

- scene → idea → implication
- evidence → doubt → new evidence → conclusion
- question → exploration → answer
- assumption → contradiction → reinterpretation
- story → reveal → meaning
- problem → failed solution → better method
- several examples accumulating toward a conclusion
- circular structures where the ending changes the meaning of the opening

Record **dependencies**. A conclusion may only work because the reader saw three examples first. A joke may only work because a phrase appeared earlier. A final paragraph may reinterpret the opening scene. These relationships matter more than the words.

## C. Dynamics (where intensity changes)

Locate where the work gets louder, quieter, faster, slower, denser, lighter, more emotional, more analytical, more humorous, more intimate, more authoritative.

Never write vague notes like "preserve the emotional tone." Name what is happening and the job it performs:

- "The understated description makes the later absurdity feel stronger."
- "The short paragraph after a dense section gives the reader a release before the argument changes direction."
- "The certainty increases as the evidence accumulates."

## D. Motifs and recurrence

Find deliberate repetition: images, metaphors, objects, phrases, questions, examples, characters, ideas, visual references, callbacks, structural patterns.

Determine what the recurrence DOES. Do not preserve a motif merely because it appears twice. Ask why it matters before deciding to carry it.

## E. Tension and release

Look for: unanswered questions, withheld information, delayed explanation, escalating evidence, surprise, contradiction, reversal, uncertainty, anticipation, reveal, resolution.

Identify where the audience is deliberately kept waiting. **AI frequently destroys this by revealing everything immediately.** Protect delayed reveals that matter.

## F. Load-bearing material

What would genuinely damage the work if it disappeared or changed? Candidates:

- a central claim
- an essential distinction
- a causal relationship
- evidence supporting a claim
- provenance or attribution
- a narrative setup
- a later reveal (or the setup that feeds it)
- a recurring image
- exact language
- an important example
- sequence
- uncertainty
- a caveat
- a structural callback

Every load-bearing element needs a REASON. Instead of "keep the opening story because it feels important" write "keep enough of the opening story to establish the assumption that the later example reverses."

## G. Material that can move or disappear

Actively list what does NOT need preserving. This is important — do not fetishize the original. Candidates:

- decorative detail
- redundant evidence
- secondary examples
- transitions that only exist because of the original format
- explanatory sentences that become unnecessary in a visual medium
- repetition useful at 2,000 words but excessive at 150
- platform-specific housekeeping

Ask: **what can disappear while the important jobs still happen?**

## H. Audience experience

What reading the current structure encourages — not a prediction of reactions. Examples: discovery, curiosity, trust, uncertainty, recognition, surprise, accumulation, contemplation, urgency, participation, intimacy, authority.

This matters because an adaptation can preserve every fact while changing how the audience understands the work (the Johnny Cash principle: the same song re-sung by a different person, older and in a different setting, means something else entirely).

## The private source model

Build and hold this internally (do not expose the full structure to the user):

```
SOURCE MODEL
Main thread:       [...]
Form:              [...]
Dependencies:      [...]
Load-bearing elements: [ {feature, function, reason}, ... ]
Motifs:            [...]
Dynamics:          [...]
Tension/reveal:    [...]
Evidence/provenance: [...]
Exact language:    [...]
Audience experience: [...]
Material safe to change: [...]
```

Update it immediately whenever the user corrects your reading. The source model is the canonical reference for ALL destination branches in a multi-output request — read the source once, branch from one model.

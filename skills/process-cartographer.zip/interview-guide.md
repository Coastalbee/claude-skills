# Process Cartographer — Interview Guide & Output Templates

## Interview Quick Reference

Use this as a checklist during the interview. Don't read it to the user — it's for your reference.

---

### Scope Lock Questions

- What do you call this process?
- What triggers it? (What's the very first thing that happens?)
- What's the final outcome? (When is it "done"?)
- How often does this happen? (Per day / week / month / client / project?)
- How many people are involved?
- Roughly how long does the whole process take end-to-end?

### Per-Step Detail Questions

- Who does this step? (Role, not just name)
- How long does it realistically take? (Not the ideal — the actual)
- What tool or system do they use?
- What do they need before they can start? (Input)
- What does this step produce? (Output)
- Does this get handed off to someone else after?

### Exception Hunting Prompts

Use these to dig deeper. Rotate through them — don't ask the same one every time.

- "What happens when this step goes wrong?"
- "Is there ever a situation where you skip this step?"
- "Does anyone ever have to redo this? Why?"
- "Is there a manual workaround here that you wish you didn't have to do?"
- "What's the most annoying part of this step?"
- "Does this step ever hold up the rest of the process?"
- "Is there a judgment call involved here? How do you decide?"
- "What happens if the input for this step is missing or wrong?"
- "Is there a version of this that only happens 10% of the time?"
- "Anything here that feels too small to mention but keeps happening?"

---

## Output Templates

### Full Process Map Format

```
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
PROCESS MAP: [Process Name]
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

Scope: [Start point] → [End point]
Frequency: [How often this runs]
People involved: [Roles]
Estimated end-to-end time: [Total time]
Total steps: [Count]

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

STEP 1: [Step Name]
━━━━━━━━━━━━━━━━━━
Action: [What happens]
Owner: [Who does it]
Time: [How long]
Tools: [What they use]
Input: [What's needed to start]
Output: [What this step produces]
Handoff: [Who gets it next, if anyone]

⚠️ Exceptions & Workarounds:
  - [Exception 1: what happens and how it's handled]
  - [Exception 2: what happens and how it's handled]

🔀 Decision Point: [If applicable — what decision gets made and what are the branches]

AUTOMATION VERDICT: [🟢 AUTOMATE NOW / 🟡 AUTOMATE LATER / 🔴 KEEP HUMAN]
Rationale: [One line explaining why]

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

STEP 2: [Step Name]
━━━━━━━━━━━━━━━━━━
[Same structure repeats]

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
```

### Automation Triage Summary Format

```
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
AUTOMATION TRIAGE SUMMARY
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

Process: [Name]
Total Steps: [Count]

🟢 AUTOMATE NOW: [Count] steps
  - Step [X]: [Name] — [Rationale]
  - Step [X]: [Name] — [Rationale]

🟡 AUTOMATE LATER: [Count] steps
  - Step [X]: [Name] — [Rationale]
  - Step [X]: [Name] — [Rationale]

🔴 KEEP HUMAN: [Count] steps
  - Step [X]: [Name] — [Rationale]
  - Step [X]: [Name] — [Rationale]

QUICK WINS (highest impact, lowest effort to automate):
  1. [Step name] — [Why this is a quick win]
  2. [Step name] — [Why this is a quick win]

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
```

### Summary Table Format

```
| # | Step | Owner | Time | Tools | Input → Output | Exceptions? | Verdict |
|---|------|-------|------|-------|----------------|-------------|---------|
| 1 | [Name] | [Role] | [Time] | [Tool] | [In] → [Out] | [Y/N + brief] | 🟢/🟡/🔴 |
| 2 | [Name] | [Role] | [Time] | [Tool] | [In] → [Out] | [Y/N + brief] | 🟢/🟡/🔴 |
```

### Mermaid Flowchart Guidelines

When generating a Mermaid diagram:

- Use `graph TD` (top-down) for most processes
- Color-code nodes by automation verdict:
  - Green fill for 🟢 AUTOMATE NOW
  - Yellow/amber fill for 🟡 AUTOMATE LATER  
  - Red/pink fill for 🔴 KEEP HUMAN
- Use diamond shapes for decision points
- Use standard rectangles for action steps
- Label edges with handoff info where relevant
- Keep node labels short (3-5 words) — the full detail is in the map

Example structure:
```mermaid
graph TD
    A[Step 1: Receive Request]:::green --> B{Valid Info?}
    B -->|Yes| C[Step 2: Create Record]:::green
    B -->|No| D[Step 3: Follow Up]:::red
    C --> E[Step 4: Assign Owner]:::yellow
    D --> A
    
    classDef green fill:#22c55e,color:#fff
    classDef yellow fill:#eab308,color:#fff
    classDef red fill:#ef4444,color:#fff
```

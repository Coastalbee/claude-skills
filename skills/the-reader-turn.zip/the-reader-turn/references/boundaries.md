# Boundaries

The shapes this skill slides into, and what to do instead.

## It becomes a comment summary

Symptom: the record reads like a digest of the thread, in the order the comments arrived. Fix: the four categories come before any writing, and the record follows the seven sections, not the thread.

## Volume becomes importance

Symptom: a paragraph about the comment with the most replies, one line about everything else. Fix: importance is decided by what a point does to the argument, not by how many people touched it.

Fix in the other direction too: do not bury a single reader's genuinely new move because only one person made it.

## Engagement language

Anything of the form "this resonated", "readers loved", "high engagement", "your audience wants". The record describes what was said and where it went. Praise from readers is not a finding.

## Trend invention

One reader, one sample, becomes "people are starting to ask". Never. One reader is one reader, and the record says so.

## Obeying the readers

If a reader demands a change, the record reports the demand. It does not recommend complying, and it does not fold the demand into section 6 as an assumption about the audience.

## Resolving the disagreement

A misunderstanding that stays unresolved is preserved as unresolved. Turning it into agreement tidies the record and destroys the thing that made it useful.

## Writing the next piece

Threads are openings, one or two lines each. No titles, no outlines, no drafts, no "here is how I would open it". If the user asks for the next piece after seeing the record, that is a different job and it happens outside this skill.

## Deciding for the writer

"The record suggests you should take the second path" belongs nowhere in the output. Section 3 describes what changed, it does not advise.

## Inventing

No invented readers, no invented quotes, no invented responses, no assumed feelings behind a response the writer did not describe. If the material does not support a section, one line saying so is the correct output.

## Being cold

None of these boundaries require distance. The record is written plainly and warmly, with the writer's own piece treated as a real piece. You are not auditing them.

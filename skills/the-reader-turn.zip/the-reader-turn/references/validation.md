# Validation

Private. Run before returning the record. Surface none of it.

## Before writing

- Did I read the whole piece, not the start of it?
- Did I read every response, including the hostile, the confused, and the short ones?
- Did I sort into the four categories before drafting any section?

## While writing

- Does every line trace to something in the material? If I was challenged, could I name the response it came from?
- Have I invented a reader, a quote, a mood, or a trend? One invented reader fails the record.
- Did volume leak into importance anywhere?
- Are disagreement and misunderstanding still there, or did I quietly settle them?
- Is section 6 written as a claim the material supports, rather than an assumption?
- Is section 7 made of openings rather than a plan?
- Does section 4 distinguish open questions from ones the piece already answered?
- Have I graded the audience, praised the response, or used engagement language?

## Before returning

- If the material was thin, did I say so in one line instead of padding?
- If a section had no support, did I write that rather than something plausible?
- Have I offered storage once, without naming a location?
- If the user pasted an earlier record, does this one read as a continuation and not a fresh start?

## The characteristic failures

Missing a repeated signal because it arrived spread across a long thread. Treating one reader's sustained argument as an audience trend. Reporting a misunderstanding as reader error. Turning a live disagreement into a resolved one because resolution reads better. Producing a clean record from material that could not support one.

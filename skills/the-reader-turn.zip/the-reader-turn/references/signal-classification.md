# Signal classification

Four kinds of response. Sort into these before writing anything, because the record reads differently depending on what it is holding.

## Isolated reaction

One reader, one response, nothing else touching the same ground. Useful as texture, not as evidence of what the audience thinks. Most responses are this, and that is fine.

In the record: mention it only if it is worth carrying. Never generalize from it. One reader is one reader.

Misuse: "readers found the ending strong" when one reader said so.

## Repeated reader signal

Two or more readers, arriving independently, converging on the same point. This is the strongest thing you will find, and it is also the easiest to fake by counting. A repeated signal means separate people went to the same place from different directions.

Tests:
- Did they arrive independently, or is one replying to another?
- Is it the same point, or the same topic with two different points in it?
- Does one of them restate the other's words, which usually means they read each other first?

One reader saying the same thing in five messages is one signal. It belongs in the record as one person's sustained point, not as a trend.

## Interesting outlier

One response that goes somewhere the original piece did not, or that opens territory nobody else noticed. It is not more important because it is unusual, and it is not less important because only one person said it. What makes it an outlier worth carrying is that it opens something: a new connection, a question the piece cannot answer from where it stands, a use of the idea the writer never considered.

In the record: name it as one reader's move. Say what it opens. Do not report it as a direction the audience is heading.

## Genuine evolution of the conversation

The conversation itself moved after publication. Something in the exchange changed a position, replaced a question with a better one, or produced a distinction that was not in the piece and was not in any single response either.

Tests:
- Can you point to the turn where it moved?
- Is the end state different from the start state, or just longer?
- Did the writer take part in the move, or did it happen among readers?

Evolution is the only category that earns the word "changed" in the section about what changed after publication.

## Rules that apply to all four

Counts never determine importance. A point raised by one reader with a real consequence outranks a point raised by six readers with none.

A misunderstanding is evidence about the writing, not a mistake by the reader. If two readers misread the same line, the line is doing something. Report it as a fact about the exchange and let the writer decide.

Agreement is not confirmation. Fifty people agreeing with the writer tells you the piece reached people who already thought that, and nothing more.

If a response is interesting but you cannot place it, put it in unexpected connections and describe what it does. Do not force it into a category to finish the section.

# Record schema

The Reader Turn Record. Seven sections, always in this order, always with their headings.

1. What readers carried forward
2. What they pushed against
3. What changed after publication
4. Questions still alive
5. Unexpected connections
6. What a future piece can assume returning readers already know
7. Possible threads worth carrying into a future related piece

## Field rules

**Source.** Every line traces to something said or asked. Quote a reader when the wording matters, otherwise describe the move ("two readers restated the durability point as a question about timing").

**Names.** Use what is available. Real names if they were given, otherwise "the reader who compared it to plumbing". Never "some readers" for one person.

**Questions still alive.** Mark each one open or closed. A question is closed only if the material shows it was answered after publication. Anything the writer answered inside the piece is not a live question and does not belong.

**Section 6 is a claim, not a guess.** Write only what the exchange actually establishes. "Returning readers already know you abandoned the first framing" is a claim, and it is only allowed if that shows up in the material. If nothing is established yet, write one line saying so.

**Section 7 stays as threads.** Openings, directions, unfinished arguments. Never a title, never an outline, never a draft. If a thread is really a whole piece, say what makes it one and leave it at that.

**Disagreement is preserved.** If a reader rejected something and the writer has not answered, the record holds the rejection as a live disagreement rather than recording it as settled.

## Length

Short material, short record. Five responses might produce two lines per section. Fifty responses might produce a paragraph per section with named readers. The seven headings never change and never get merged. Never pad.

## Worked example (shortened)

> **Reader Turn Record: The piece about [subject] · [date]**
>
> **What readers carried forward.** The point about doing the work before the tool arrived. Three readers restated it in their own words, and one of them applied it to a field you did not mention.
>
> **What they pushed against.** Two readers read your line about [X] as a claim about [Y], which you did not make. Either the wording is doing that or they came in with the other argument already in mind. Worth knowing which.
>
> **What changed after publication.** The question moved from whether the thing is true to when it applies. That happened in the exchange, not in the piece.
>
> **Questions still alive.** Whether [question], asked by two readers and unanswered. (open) Whether [question] applies outside your own field. (open)
>
> **Unexpected connections.** One reader connected it to [unrelated area] through [their route]. Single reader, no one else went there, but it opens something.
>
> **What a future piece can assume returning readers already know.** That you take the first framing as unfinished. That [term] now means what the exchange made it mean.
>
> **Possible threads worth carrying.** [two or three openings, one line each]

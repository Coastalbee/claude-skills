# Storage

The record lands in the chat by default. Keeping it somewhere is the user's choice, offered once, after the record is written.

## The one offer

> One thing before I go: if you want this kept somewhere (a file, Obsidian, Notion, a doc), name the place and I'll write it there. If you'd rather not, it stays in this chat.

Then stop talking about it. No folder suggestions, no "shall I create one", no reminder at the end of the session.

## If they name a place

Write the record there using the tools you have. Before you write, confirm the destination back in one line ("saving to [path]" or "adding to your Notion page [name]"), because a record that lands in the wrong place is worse than one that stays in the chat.

If you do not have access to the place they named, say so plainly, tell them what you can do instead (print the record as one clean block to paste), and leave the choice with them.

## If the place already holds records

Append. Never overwrite a store, never rewrite an earlier record to agree with the new one. Add the new record under its own date heading with the piece title.

If the store appears to be for a different subject, ask once whether they want it added there anyway. Do not silently choose a different location.

## Established history locations

A Reader Turn history becomes reusable only when the user has explicitly established a location for that thread and the location is available in the current context or accessible through the tools you have.

When a user returns to the same thread later and that established location is known and accessible, read the existing history before asking them to paste earlier records again.

Do not search arbitrary folders, notes, drives, or databases trying to guess where a history might live. Do not infer a destination from a topic name. Do not assume a location from a previous unrelated Reader Turn. If the location is not explicitly available, ask for the earlier record or the history location instead.

Reading an established history does not authorize writing to it. The new Reader Turn Record is still written in chat first, and the user is still offered storage once afterward. Only append if they choose to keep the new record there.

## Nothing is automatic

No writes before the offer, no writes after a refusal, no default folder invented for the user, no state kept anywhere they did not name. A user who says no is making a normal choice, not declining a feature.

## What makes the record worth storing

The date, the piece title, and the status of each open question. Without those, a stack of records cannot be read later as history.
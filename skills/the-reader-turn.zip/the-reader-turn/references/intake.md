# Intake

What arrives, and what to do when it arrives badly.

## What counts as the piece

Anything the writer made and sent out: a newsletter, an essay, a video or its transcript, a podcast episode and its notes, a talk, a thread, a post. You need enough of it to know what a reader was actually given. A title and a summary is not enough. If it is a video and they paste only the description, ask for the transcript.

## What counts as a response

Comments and replies on the piece, replies to the email, private messages, emails sent directly, notes left in a community space, quote-posts that engage with an argument. Response length does not matter. A two-word reply can carry more than a paragraph, and a long reply can carry nothing.

Include responses that are hostile, confused, or off topic. Those are often where the useful history is, and the temptation is to drop them.

Responses the writer wrote back are also material, because they are part of what happened between the two of them. Note them as the writer's own turn, not as reader response.

## Mess is expected

Responses arrive pasted in any order, with platform noise, timestamps in three formats, and no names. Do not ask the user to clean it up. Read it as it is, and if a name is missing, refer to the reader by what they said ("the reader who compared it to plumbing") rather than inventing a label.

If a response is truncated or clearly cut off mid-sentence, use what is there and say in the record that part of it was missing.

## One side only

If you have the piece and no responses, say so and stop. There is nothing to read yet, and the record would be invention. Offer to run it once responses exist. Do not produce an imaginary audience.

If you have responses and no piece, ask for the piece. The record leans on comparison between what was sent and what came back, and without the original you cannot tell a request from a misreading.

## Volume

A piece with three responses gets a short record. A piece with two hundred gets a longer one. Neither is a better record. If the user offers to fetch more responses before you start, take them; if they say this is all that came back, work with it and do not remark on the number.

---
name: chain-of-draft
description: Use after a draft has been finished, inside the same working session where it was made, to produce a readable record of how it got made. Trigger on "chain of draft", "run chain of draft on this", "the piece we just finished", "record how this got made", "provenance report", "who wrote what in this draft", "I need to show how this was created", or when a writer, editor, researcher, student, or client wants a record of how AI participated in producing a piece. The skill reads the actual conversation that produced the work and reconstructs what came from the human, what came from AI, what developed through the exchange, what entered from outside sources, and which decisions shaped the final draft. This is process evidence, not an authorship score: no percentages, no detector results, no claims about what the record proves legally.
---

# Chain of Draft

The finished language carries only part of the history behind it. This skill keeps the rest.

A draft has two histories: what it says, and how it came to say that. The second one is invisible in the file. It lives in the working session, in the rejected framings, the correction you made twice, the argument that only appeared because the first one failed, the paragraph that was rewritten by hand after a suggestion got close but not close enough.

Your job is to read that session and reconstruct it as accurately as the evidence allows. You are writing a record, not a verdict. Every line you produce is something the session shows.

Chain of Draft is designed primarily to run **at the end of the same conversation in which the draft was made**. That live working context is the strongest version of the skill because the complete sequence of brainstorming, drafting, rejecting, editing and rewriting is already present.

A pasted or exported transcript is a fallback when the original working conversation is no longer directly available. If you use one, say in the provenance limitations that the record is based on a supplied transcript rather than the live working context.

## Say this when you start

> I'll read back through the working session and write you a Draft Provenance Record: what came from you, what came from the AI, what grew out of the back and forth between you, what came in from outside sources, and the decisions that shaped the final text.
>
> No percentages, no detector, no claims about what the record proves about authorship.

If the working session is already present, acknowledge in one line and begin immediately. Do not ask for another confirmation and do not explain the method.

If the relevant creation history is not present, ask whether the user has the original session or a transcript they can provide. Do not reconstruct provenance from the finished text alone.

## Step 1: Check that there is a session to read

Before anything else, work out whether the making of this piece is actually present. A pasted final draft with no history is not a session. A fresh chat where the user dropped in a text written elsewhere is not a session. Details, the signals of absence, and how to accept a pasted or partial history are in `references/availability.md`.

If the history is not here, say so and stop. Do not reconstruct provenance from the finished text, and do not present a plausible story of how the piece might have been made.

A partial session is workable. A missing one is not.

## Step 2: Read the session in order

Read the whole thing, start to finish, before classifying anything. You need the order, because provenance is about sequence: a phrase that appears in the final draft means something different if it was typed by the user or proposed by the AI two turns earlier.

Note where the session begins relative to the work. If the user arrived with an outline already written, that outline is starting material, and anything before it is outside what you can see.

## Step 3: Sort the material

Four buckets: human contribution, AI contribution, collaboratively developed, external material. Definitions, examples, and the edge rules for the hard cases (who originated a phrase versus who decided it stayed) are in `references/contribution-taxonomy.md`.

The collaborative bucket is mandatory and it is the one that makes this record worth anything. Material that emerged through an exchange does not get pushed into the human column to make the writer feel better, or into the AI column to be cautious. If the exchange produced it, the exchange is what you describe.

## Step 4: Apply the evidence standard

Every claim in the record has one of three evidence levels: documented, reasonably derived from the exchange, unknown. How to decide among them is in `references/evidence-standard.md`.

**Documented is the unmarked default.** If the session directly shows something, state it plainly. Do not append "Documented" to every sentence.

Explicitly mark only the claims whose status matters because certainty is limited:

- **Reasonably derived from the exchange** when development is visible but ownership or exact origin is mixed.
- **Unknown** when provenance cannot be established.

Never invent a missing stage to make the chain look complete.

## Step 5: Write the Draft Provenance Record

Use the template in `references/output-shape.md`: draft, starting material, human contribution, AI contribution, collaboratively developed, external sources, important editorial decisions, chain of development, provenance limitations.

The chain of development is the compact arrow sequence of how the piece moved. Every stage in it has to be a point you can find in the session.

The provenance limitations section is not a formality. It names exactly what the session cannot establish, including anything before the session started and anything the user did away from it. If the user later edited the piece somewhere else, that is unknown, and it says so.

## Length and detail

The sections are fixed. Their size follows the session. A twenty-minute brainstorm gets a short record, a two-day working session with several restarts gets a long one, with more than one entry under collaborative development and under editorial decisions.

Never pad a thin session to look thorough, and never flatten a long one into a summary to look tidy. A record that reads like a summary of a long session has failed at its job.

## What this is not

Not an authorship score. Not an AI detector. Not proof of anything legal. Full list in `references/boundaries.md`.

You also do not grade the draft. Not its quality, not its originality, not how much of it is good. The record is about where things came from, not how well they turned out.

## Before you return

Run the private checks in `references/validation.md`. Surface nothing from the checklist. If the record is thin because the session was thin, one line saying so is the right output.

## References

- `references/availability.md`: the same-session-first availability gate, fallback transcripts, and partial histories
- `references/contribution-taxonomy.md`: the four buckets, examples, and the edge rules
- `references/evidence-standard.md`: documented as the unmarked default, reasonably derived, unknown, and how to phrase them
- `references/output-shape.md`: the record template, the arrow chain, a worked example
- `references/boundaries.md`: the claims this skill never makes and what to say instead
- `references/validation.md`: private pre-return checks and failure modes
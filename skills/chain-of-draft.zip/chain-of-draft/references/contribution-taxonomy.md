# Contribution taxonomy

Four buckets. Sort as you read, but do not start writing until you have read the whole session, because an early entry often changes meaning once you see later turns.

## Human contribution

The premise. Raw ideas in the user's own words. Experiences and material only they could supply. Arguments they brought in. Examples they chose. Phrases and passages they typed themselves. Edits they made by hand after an AI version existed. Corrections. Rejected suggestions. Direction changes they initiated. Judgment calls about what belonged in the piece and what did not.

A rejection is a contribution. The session shows the user refused a framing, and the final draft is different because of it. That belongs in the record.

## AI contribution

Wording first produced by the AI that survived into the draft. Structural suggestions. Proposed arguments or examples the user kept. Edits and line-level rewrites. Research assistance. Reframings. Organizational changes. Alternatives the user accepted.

Accepted is still contributed. A paragraph the AI wrote that the user kept unmodified is an AI contribution, and saying so is the whole point of the record.

## Collaboratively developed

The category that has to work. Material that belongs to neither side cleanly, because the exchange produced it.

The classic shape:
- the human introduces an idea
- the AI reframes it
- the human rejects part of the reframe
- a new distinction emerges from the exchange

That distinction is not the human's idea and not the AI's suggestion. Describe the sequence and name the thing that came out of it.

Other shapes: the AI asks a question that makes the user articulate something they had not written down; the user supplies an example and the AI's rewrite changes what the example proves; the user's correction of the AI's framing produces a better framing neither had at the start.

Do not force this bucket empty. A report with nothing under collaborative development in a session full of back and forth is a report that failed.

## External material

Research, quotations, linked sources, books, articles, other people's ideas, uploaded documents, references consulted during the session. Say where each entered and what it did in the piece.

If the session shows a source was consulted but not whether anything from it survived, say that. Consulted is not the same as used.

## Edge rules

**Origin versus decision.** Two different facts: who produced a phrase first, and who decided it stays. Attribute the origin in the contribution buckets, and record the decision in important editorial decisions. Do not merge them, and do not let the later decision overwrite the earlier origin.

**The user retyped it.** If the AI proposed wording and the user retyped it with changes, this is collaborative. Describe it as the AI proposal plus the user's rewrite, not as one or the other.

**Unclear origin.** If the session genuinely does not show who produced something, it goes under collaborative only when the exchange shows mixed development. Otherwise it is unknown, and unknown is written as unknown.

**The user's own words in an AI draft.** Text the AI wrote that the user edited heavily is collaborative, and the record can say the final wording is the user's while the structure came from the AI. Attribution happens at the level of what actually changed.

**Starting material.** What the user arrived with belongs at the top of the record, before the buckets, because it was not made in the session. If it was made in an earlier session the user pastes in, then it was made in a session and is attributed normally, with a note about which session.

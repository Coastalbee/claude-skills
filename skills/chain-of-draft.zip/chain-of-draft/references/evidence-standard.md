# Evidence standard

Three levels. Every claim in the record has one, but the reader should not have to wade through a label after every sentence.

## Documented

Directly visible in the conversation. You can point to the turn.

**Documented is the unmarked default.** State the claim plainly.

Good:
> The premise and both examples came from you.

Avoid:
> The premise and both examples came from you. Documented.

The record should read like a clear account of what happened, not an evidence ledger with a stamp after every line.

## Reasonably derived from the exchange

The development is visible, but ownership is mixed or the final form cannot be attributed to one turn. This is where many honest attribution questions land, and the limitation should be visible to the reader.

Mark these claims explicitly.

Phrasing:
> **Reasonably derived from the exchange:** your rewrite kept the shape of the suggestion but changed the claim it makes.

> **Reasonably derived from the exchange:** the second half of the section appeared after the rejection, but the session does not show whether you or the AI supplied the new opening line.

Say what is visible and what remains uncertain. Never write a derived claim in the same voice as a documented one.

## Unknown

Provenance cannot be established. This is a valid result and an expected one.

Mark it explicitly only where the unknown matters to the provenance record, or gather it into Provenance Limitations when that is clearer.

Phrasing:
> **Unknown:** the first part of the work happened before this session.

> **Unknown:** whether the external source informed the final paragraph is not visible here.

A record with several unknowns is a working record. A record with no unknowns is either a very clean session or a record that guessed.

## Rules

Do not upgrade a derived claim by writing it confidently. The words do not carry proof.

Do not downgrade a documented claim to seem modest. If the session shows it, say it plainly.

Do not attach "Documented" to every directly supported statement. The absence of a label means the claim is directly visible in the session unless the surrounding wording says otherwise.

Do not tag per section and let one label cover a paragraph of mixed certainty. Mark the specific derived or unknown claim that needs the distinction.

Never invent a stage to fill a gap in the chain of development. The chain can have a jump in it, and the limitations section names the jump.

If the user pushes for more certainty than the session supports, decline plainly and explain that the level is set by what the session shows, not by what the report would prefer.

## What the levels are for

They let a reader tell the difference between what the session directly shows and what a careful reader can reasonably infer, without turning the report into a police document.

The ideal reading experience is simple: most of the record reads naturally because most of it is documented; uncertainty becomes visible exactly where uncertainty exists.
# Boundaries

The claims this skill never makes, and what to say instead.

## No percentages

Never "82% human", never a ratio, never a majority estimate. There is no measurement behind it.

If asked: the session shows a sequence of moves, not a proportion, and any number would be a guess dressed as a finding.

## No detector scores

No AI-detection results, no "reads as AI-written", no perplexity, no borrowed tool. A detector result is not evidence about who did what in a session, and mixing it in corrupts the record.

## No authorship claims

The record does not prove who owns the work. It does not establish legal authorship, does not discharge a disclosure duty, and does not certify anything to a third party.

If a client, institution, or editor is the reason for the request, say plainly that this is a readable record of process, not a certification, and that what it does and does not establish is set out in its limitations section.

## No cleanliness claims

The record does not prove the work contains no AI-generated language, and it cannot be used to argue that it does. It covers what happened in one session, nothing more.

## No guessing outside the session

Anything before the session, after it, or beside it is unknown unless the user states it. Do not infer what the user probably did elsewhere.

## No forcing collaboration into a side

Not into the human column, not into the AI column. The exchange is described as an exchange even when a cleaner answer is available.

## No grading the draft

Not how good it is, not whether the AI improved it, not whether the user's version is stronger. Compliments and criticisms both stay out.

If the user asks how the piece turned out, that is a different conversation and it happens after the record, clearly separated from it.

## No undoing the record because it is uncomfortable

If the session shows the AI wrote most of a section the user presented as their own thinking, the record says so. If the user asks to soften it, offer to add their own account as a documented note, and do not change the attribution.

## No producing a record when the gate fails

Restated here because it is the boundary most likely to be crossed under pressure. A record built from the finished text alone is fiction with a professional format.

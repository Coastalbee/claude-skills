# Output shape

The Draft Provenance Record. Nine parts, this order.

## Draft

Name or description of the final piece. One or two lines.

## Starting material

What the user entered the session with. Their own words where possible. If they arrived with an outline, a rough draft, or a set of notes, this is where it goes.

## Human contribution

The important material clearly originating from the user. Premise, arguments, examples, supplied phrases, manual edits, corrections, rejections, direction changes.

Directly documented material is stated plainly. Do not append an evidence label to every line.

## AI contribution

The important material clearly originating from the AI. Wording that survived, structure, proposed arguments and examples, edits, research help, reframings, accepted alternatives.

Again, directly documented material is stated plainly.

## Collaboratively developed

Ideas, distinctions, structures, or passages whose final form emerged through the back and forth. Describe the sequence and name what came out of it.

When the exchange clearly produced the result but exact ownership is mixed, explicitly mark the claim **Reasonably derived from the exchange**.

This section should have real content in any session where the work moved.

## External sources

Research and outside material brought in during the session, with where each entered and what it did. Note separately anything consulted but not visibly used.

Use **Unknown** only when the relationship between the source and the finished draft cannot be established.

## Important editorial decisions

The moments where the user accepted, rejected, changed, restored, moved, or reframed something, with what the decision did to the piece. This is where decisions live, as distinct from origins.

## Chain of development

A compact arrow sequence of how the draft evolved. Every stage must be a point in the session.

`raw idea → user outline → AI structural suggestion → user rejects framing → new distinction emerges → research added → AI line edit → user rewrite → final draft`

Keep it to the moves that shaped the piece. A chain with fifteen arrows is usually a session log, not a chain.

## Provenance limitations

What the conversation cannot establish. When the session starts relative to the work, what happened outside it, whether the record is based on live working context or a supplied transcript, anything reasonably derived or unknown that materially affects the record, and anything the user did to the piece afterwards.

## Evidence presentation

The record uses three evidence levels, but only uncertainty gets visually marked:

- Directly documented claims are stated naturally with no label.
- **Reasonably derived from the exchange** is labeled where the development is visible but attribution is mixed.
- **Unknown** is labeled where provenance cannot be established, or named in Provenance Limitations when that reads more cleanly.

Do not turn the report into a sequence of evidentiary stamps. The rigor should be visible exactly where the evidence becomes uncertain.

## Length

The nine parts never change. Their size follows the session. A short brainstorm gets a compact record. A long session with restarts gets a full one, including more than one entry under collaborative development and under editorial decisions.

Never pad a thin session and never flatten a long one. A record that reads as a summary has failed, and a record that reads as a session log has also failed.

## Worked example, shortened

> **Draft Provenance Record: [piece name]**
>
> **Starting material.** You arrived with a one-line premise and two examples you had already chosen.
>
> **Human contribution.** The premise, both examples, and the closing paragraph came from you. You typed the closing paragraph after cutting the AI's version. You also insisted twice that the piece avoid a tidy ending, a constraint the AI did not introduce.
>
> **AI contribution.** The structure of section three was proposed by the AI and kept. The sentence that became the opening was also first proposed by the AI and survived with one word changed by you.
>
> **Collaboratively developed.** The distinction between the two kinds of reader emerged through the exchange: you raised the subject, the AI split it into two, you rejected the second half as not a real category, and the surviving distinction appeared in the third exchange. **Reasonably derived from the exchange:** the term the piece now uses first appeared in the AI's rejected version, while the final definition came from your rewrite.
>
> **External sources.** [Study] entered in turn [n], brought by you, and the AI summarized it. **Unknown:** whether the quoted line in the final piece came from the source itself or from the AI's summary.
>
> **Important editorial decisions.** You rejected the reframe of paragraph four, restored the original ending after an AI edit, and moved the second example earlier, which changed what the section proves.
>
> **Chain of development.** `premise → user outline → AI structural suggestion → user rejects framing → new distinction emerges → research added → AI line edit → user rewrite → final draft`
>
> **Provenance limitations.** The session starts after you had already chosen the examples, so how they were found is unknown. Whether the possibility of a third category was considered outside this session is also unknown.
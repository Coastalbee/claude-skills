# Availability

The gate. Nothing in this skill works if it does not pass.

## Primary use: the same working conversation

Chain of Draft is designed to run at the end of the conversation in which the piece was actually made. The strongest record comes from the live working context because the sequence of brainstorming, drafting, rejecting, editing and rewriting is already present.

If that working session is present, begin from it. Do not ask the user to re-paste material that is already visible and do not require another confirmation before reading.

## Fallback use: a supplied transcript

If the original conversation is no longer directly available, a pasted or exported transcript can be used as a recovery path.

Treat it as supplied evidence, not as equivalent to live context. The final provenance limitations must state that the record was reconstructed from a supplied transcript and must name any visible gaps between sessions or missing turns.

A pasted transcript is accepted as it arrives. Do not ask the user to clean it up.

## What counts as a session

A working session where the piece was actually made: brainstorming, outlining, drafting, editing, rejecting, rewriting. It can be one long chat, the current chat plus a pasted earlier section, or a transcript the user provides as fallback.

It must show the work happening. A session that only contains the finished text, however long, is not a creation history.

## Signals that the history is not here

- Only the final draft is present, pasted or attached.
- The chat is new and the piece arrived whole in the first message.
- The user says "I wrote this elsewhere" or "I only have the file".
- The piece was produced by another person and the user wants it analyzed.
- The user wants a verdict on a text rather than a record of a process.

If any of these is present, the gate has failed unless the user can supply the working history.

## What to say

Say it plainly, without apology and without offering a workaround that would be guesswork:

> I can only build Chain of Draft from the conversation where the piece was made, or from a transcript of that working history. That creation history isn't here. Anything I produced from the finished text alone would be a story about provenance, not provenance.
>
> If you have the original session or an export of it, send that and I'll run the record on the evidence that's actually there.

Then stop and wait. Do not offer a reduced version of the record. Do not produce a record with everything marked unknown, because that is a pretend record.

## Several sessions

If the user supplies several separate sessions, read them in the order they name. Treat gaps between them as gaps, not as continuous work.

If the history is enormous and arrives in parts, work through all of it before writing. Partial reading produces wrong attribution, which is the one failure this skill cannot afford.

## Partial histories

Most real sessions are partial. The gate passes if enough of the making is visible to attribute honestly, and the record then says what is missing:

- when the visible history starts, relative to the work
- what the user brought in already made
- anything that happened off-screen
- whether the evidence comes from live context or a supplied transcript

Mark the boundary instead of guessing across it.

## After the gate passes

Confirm in one line what history you have and what part of the work it covers, then read it. Do not ask the user to summarize the session for you, because their summary is itself a claim you would then be reporting as evidence.
# Validation

Private. Run before returning the record. Surface none of it.

## The gate

- Did I confirm the creation history is actually present, rather than assuming it?
- If the live working conversation is present, did I use it directly instead of asking the user to re-paste or reconfirm?
- If I am using a supplied transcript as fallback, did I say so in Provenance Limitations?
- If the history is partial, did I mark where it starts and stop there?
- If it is absent, did I refuse instead of producing a reduced record?

## Attribution

- Can I point to the turn behind every directly documented claim?
- Are the derived claims explicitly marked so they do not read as certain?
- Did I avoid stamping "Documented" after ordinary supported sentences?
- Is the collaborative section populated, and does it describe the sequence rather than a tidy owner?
- Did I separate origin from decision, or did one overwrite the other?
- Did a rejection, a correction, or a change of direction get recorded as a contribution?
- Is anything attributed to the user that the session does not show them producing, or the reverse?

## The chain

- Is every stage of the arrow sequence a point in the session?
- Did I bridge a gap with an invented stage instead of naming it in limitations?
- Is the chain about the moves that shaped the piece, or is it a log of the session?

## The claims

- Any percentage, ratio, or pseudo-measurement anywhere? Remove it.
- Any detector result, authorship claim, or cleanliness claim?
- Did I grade the piece, praise the session, or compliment the collaboration?
- Is the limitations section specific, or is it a formality covering nothing?
- Are unknowns visible where they matter without being repeated mechanically in every section?

## Length and shape

- Does the record's size match the session's size?
- Did I pad a thin session, or flatten a long one into a summary?
- Does a long session have more than one entry under collaborative development and editorial decisions?
- Does the report read like a useful process record rather than a police report or evidence ledger?

## The characteristic failures

Producing a record without a session. Guessing the origin of a phrase because the final draft makes it obvious who would have written it. Emptying the collaborative bucket because binary is easier to read. Letting a derived claim sound documented. Labeling every supported sentence until the report becomes unreadable. Filling a gap in the chain instead of naming it. Tidying the record into a case for the writer's originality, or into a confession.
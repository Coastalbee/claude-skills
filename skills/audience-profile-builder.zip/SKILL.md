---
name: audience-profile-builder
description: "Build a complete, reusable Audience Profile .md file that documents who someone's audience really is — their personas, psychology, fears, triggers, language, and behavior — so it can be plugged into any AI workflow that needs to know who they're talking to. Use this skill whenever someone wants to build their audience profile. This skill runs a structured interview and produces a downloadable .md file ready to plug into any AI workflow."
---

# Audience Profile Builder

Build a complete Audience Profile .md file through structured interview and synthesis. The output is a reusable Core file — not a one-time reference, but a living document that makes every piece of content, every offer, and every workflow smarter.

## Why this matters

Most audience profiles fail because they describe demographics, not psychology. "Women 35-45 who run small businesses" tells you nothing about what they fear at 2am, what finally made them open their wallet, or what words they use when describing their own problem. This skill excavates all of that through structured interview, pushes back on vague answers, and produces a document specific enough to actually drive decisions.

## Instructions

The process has three phases. Move through them in order. Never skip ahead.

---

### Phase 1: Setup and Context

1. Explain what you're building: "We're building your Audience Profile — a .md Core file that documents who your audience really is, in enough depth that you can plug it into any AI workflow. Every piece of content, every offer, every CTA will be smarter because of this file."

2. Tell them the process takes 45–90 minutes depending on how many personas they have, and covers: shared DNA across their audience, individual persona deep-dives, and a final review round.

3. Check for Core files. Ask: "Do you have any of these already: a Voice Profile, Brand Strategy, or Offers & Products doc? If so, share them — they'll help me ask better questions." Pull context from anything provided. If none exist, proceed.

4. Ask the opening context question — ONE question only, then wait:
   > "Tell me what you do and who you think you're serving. Don't give me the polished version — give me the honest one. Who's actually paying attention to you, buying from you, or reaching out?"

5. After they respond, ask about data:
   > "Do you have any real-world signals to work with? DMs, comments, emails, sales calls, analytics, reviews — even a handful of observations? Share what you have. If you have nothing yet, we'll work from intuition and I'll push harder."

---

### Phase 2: The Interview

Work through this in two parts: Shared DNA first, then individual personas. 

**Read `references/interview-guide.md` for the complete question bank, follow-up prompts, and pushback examples for every section.**

Ask ONE question at a time. Follow up when answers are vague. Push back when answers are too generic to be useful. Never stack questions.

#### Part A: Shared DNA

Before identifying individual personas, find what's true across ALL of them. Work through these sections in order:

1. **Shared motivations** — Why do they really come to this person? What are they actually trying to get?
2. **Shared enemies** — What are they fighting against, externally and internally?
3. **The gap they're trying to close** — Where are they now vs. where they want to be? Push for specificity.
4. **Shared language and references** — The shorthand, phrases, cultural touchstones that make them feel understood.
5. **What they've already tried** — Solutions attempted before. What failed and why.
6. **How they found the subscriber** — The most common path into their world.

#### Part B: Persona Identification

Once Shared DNA is complete, ask:
> "Now let's separate your audience into distinct groups. Don't give me demographics first — give me the situation each type of person is in. How many meaningfully different segments do you have?"

**If they name only one persona:** Push back. Ask if there's a meaningful difference between someone new vs. experienced, employed vs. independent, early stage vs. scaling. Find the real splits.

**If they name more than 5:** Narrow it. Ask which 2–4 actually matter most for their content, offers, and decisions.

**Lock in the persona list before proceeding.** Name each persona, confirm the list, then go deep on each one.

#### Part C: Per-Persona Deep Dive

For EACH persona, cover ALL 15 sections from the interview guide. In order:

1. Who they are
2. What they call themselves
3. What they want
4. What they fear
5. Conversion triggers
6. The decision moment
7. How they judge value
8. What makes them leave
9. How they talk about the problem
10. Where they hang out
11. Relationship with paying
12. Day in the life
13. Before and after
14. What they've already tried (persona-specific)
15. How they describe the subscriber to others

Complete all sections for one persona before moving to the next.

---

### Phase 3: Synthesis and Output

1. Once all personas are complete, tell the subscriber: "I have everything I need. Give me a moment and I'll produce the full Audience Profile."

2. Compile the complete .md file using the template in `references/output-template.md`. 

3. Every section must contain specific, concrete details drawn from the interview. If a section reads like it could belong to anyone, rewrite it before presenting.

4. Present the full document. Ask:
   > "Read this as if someone else wrote it about your audience. Does it capture who they actually are — or a polished version you wish were true? What's wrong, missing, or off?"

5. Iterate once based on feedback. Then finalize.

6. Deliver with: "Save this as a .md file and upload it to Claude as a Skill or add it to your Project. Any time you're writing content, building an offer, or making a product decision with this file active, Claude will know exactly who you're talking to."

---

## Interaction Rules

- **One question at a time.** Never stack questions in a single message.
- **Specifics over adjectives.** When someone says "they want to grow" or "they're frustrated," redirect: "Give me the specific version — what does that look like for this person in their situation?"
- **Push back on vague personas.** "Entrepreneurs who want to grow their business" is not a persona. Push until you have something behavioral and situational.
- **Catch aspirational vs. actual.** If their description sounds like who they wish they served rather than who actually shows up — name it. Build the profile around reality.
- **Never let "I don't know" be a dead end.** Offer a different angle, a comparison, or an example to react to.
- **Before/after must be concrete.** "More confident" is not a transformation. Push for what's different on a real Tuesday.
- **Complete all sections before producing output.** The depth of the interview is the quality of the document.

---

## Guardrails

- **Never invent personas or details** not grounded in what the subscriber actually shared. If you don't have enough, ask more questions.
- **Never collapse distinct segments into one persona.** If two groups need different things, they are different personas.
- **Never accept vague answers as final.** "They want to be successful" is not an answer. Push every time.
- **Never use generic marketing language** in the output. No "pain points," "value propositions," or "target demographics." The document should sound like a smart human wrote it about real humans.
- **Never rush to output** if the interview is thin. More questions now means a better document.
- **Never produce a document that couldn't be told apart from anyone else's.** If you swap out the name and it still works, the profile has failed.

---

## Troubleshooting

**Subscriber gives only demographics:**
Redirect immediately. "Age and job title don't tell me what they're afraid of or what finally made them buy. Walk me through what's happening in their life right now."

**Subscriber insists they have one audience:**
"Let's pressure-test that. Is the person who's been doing this for 10 years in the same situation as someone who's 6 months in? Do they need the same thing from you?" Find the real segments.

**Before/after stays abstract:**
"'More confident' isn't concrete enough to write a CTA from. What are they doing on a Tuesday morning after working with you that they weren't doing before? What stopped happening?"

**Subscriber has no data:**
Work from intuition, but push harder on specifics. "You may not have the DMs yet, but you have instincts. Who's the most memorable person who reached out to you — what was their situation?" Use real examples to anchor the profile.

**Output feels generic after draft:**
Go back to the interview. Find the one detail that's specific to this subscriber's audience and couldn't belong to anyone else. Rebuild the section around that detail.

# Audience Profile Builder — Interview Guide

This is your question bank. Use it during Phase 2. Ask ONE question at a time. Follow up when answers are vague. Push back when answers are too generic to be useful.

---

## PART A: SHARED DNA

These questions surface what's true across ALL personas before you separate them.

### 1. Shared Motivations

**Primary question:**
"Why do people come to you? Not the polished answer — the real one. What are they actually trying to get?"

**Follow-ups if shallow:**
- "What do they tell their friends when they recommend you? What's the sentence?"
- "What would make them feel like working with you / reading you was worth it?"
- "What are they optimizing for — time, money, status, peace of mind, something else?"

**Pushback trigger:** If they say "they want to grow their business" or "they want to be successful" — stop. Ask: "Grow how? To what end? What does success look like for them specifically?"

---

### 2. Shared Enemies

**Primary question:**
"What's your audience fighting against? I'm looking for two things: the external enemy (a system, an industry, a trend, a type of person) and the internal enemy (a fear, a pattern, a story they tell themselves)."

**Follow-ups if shallow:**
- "What do they complain about most?"
- "What makes them feel like the world is working against them?"
- "What do they blame when things don't go well?"

**Pushback trigger:** If they only name one type of enemy, prompt for the other: "That's the external one. What's the internal version — the thing they're fighting inside themselves?"

---

### 3. The Gap They're Trying to Close

**Primary question:**
"Describe where your audience is RIGHT NOW — their actual situation, not their ideal. Then describe where they want to be. What's the specific distance between those two points?"

**Follow-ups if shallow:**
- "What does their day-to-day look like before they found you?"
- "What does their life or work look like AFTER — specifically? Not 'better' — what's different on a Tuesday afternoon?"
- "What would they say changed, if you asked them 6 months in?"

**Pushback trigger:** If before/after is abstract ("they want to feel more confident"), push: "What does that confidence look like in practice? What are they doing differently? What are they no longer doing?"

---

### 4. Shared Language and References

**Primary question:**
"What words and phrases does your audience use when they describe their own problem? Not your words — theirs. What do they say in DMs, comments, emails?"

**Follow-ups:**
- "What cultural references, shorthand, or insider language does your audience share?"
- "What can you say that makes them immediately feel understood — like you read their mind?"
- "What words do THEY use that you've borrowed because they just fit?"

---

### 5. What They've Already Tried

**Primary question:**
"Before finding you, what did they try? Courses, tools, other experts, DIY approaches — what have they attempted and why didn't it work?"

**Follow-ups:**
- "What did those solutions promise that yours doesn't? What did yours promise that those didn't?"
- "What made them give up on the old approach and look for something new?"
- "What are they skeptical about because of past failures?"

---

### 6. How They Found You

**Primary question:**
"How do people actually end up in your world? What's the most common path?"

**Follow-ups:**
- "Is it search, social, referral, word of mouth, something else?"
- "What were they looking for when they found you — were they searching for a solution, or did you interrupt them?"
- "What made them stay after they found you?"

---

## PART B: PERSONA IDENTIFICATION

### Separating Personas

**Primary question:**
"Now that we've mapped what's shared — how many distinct types of people are in your audience? Walk me through them. Don't give me demographics first. Give me the situation they're in."

**Pushback trigger — if they name only one persona:**
"Are you sure that's one group, or are there meaningfully different situations inside it? For example — someone who's brand new vs. someone who's been at it for a few years. Or someone who's employed vs. someone who's building their own thing. Do those people need different things from you?"

**Pushback trigger — if they name more than 5:**
"That's a lot of segments. Let's find the 2–4 that actually matter most for your decisions. Which ones are you primarily writing for, selling to, or building for?"

---

## PART C: PER-PERSONA DEEP DIVE

For EACH persona, cover ALL of these sections. Don't skip any.

### 1. Who They Are

**Primary question:**
"Paint me a picture of this person. Not age and job title — who are they, really? What's their situation? What stage of life or work are they in?"

**Follow-ups:**
- "What do they do Monday through Friday?"
- "What does their relationship with their work look like?"

---

### 2. What They Call Themselves

**Primary question:**
"How does this person identify? What label do they use for themselves — 'freelancer', 'consultant', 'founder', 'creator', 'coach'? Or do they resist labels?"

**Why this matters:** The word they use to self-identify is often the word that makes your copy land. "Solopreneur" vs "independent consultant" vs "one-person business" will resonate differently with the same person.

---

### 3. What They Want

**Primary question:**
"What does this persona want — their primary goal from working with you or consuming your content? Not the surface desire. The real one underneath it."

**Follow-ups:**
- "What would make them feel like this was worth their time and money?"
- "What are they trying to prove — to themselves, to others?"

---

### 4. What They Fear

**Primary question:**
"What keeps this person up at night? What's their specific fear — not generic anxiety, but the thing that makes their stomach drop?"

**Follow-ups:**
- "What's the worst-case scenario in their head?"
- "What are they afraid people will think of them?"
- "What do they secretly worry is true about themselves?"

**Pushback trigger:** "That's too generic. Give me the specific version — what's the exact thought they have at 2am?"

---

### 5. Conversion Triggers

**Primary question:**
"What finally makes this person decide to act — to buy, subscribe, reach out? What's the moment something shifts for them?"

**Follow-ups:**
- "Is there a specific event or circumstance that pushes them over the edge?"
- "What do they see or hear that makes them think 'I need this'?"
- "What's the straw that breaks the camel's back?"

---

### 6. The Decision Moment

**Primary question:**
"What's the specific situation — not just the emotion, but the actual circumstances — that makes this persona go from 'interested' to 'I need this now'?"

**Why this matters:** This is different from conversion triggers (emotional). This is situational — the meeting that went badly, the competitor they saw move faster, the Saturday they spent 4 hours on something that should've taken 30 minutes.

**Follow-ups:**
- "Where are they when this happens — at their desk, on their commute, in a meeting?"
- "What just happened right before they reached out or bought?"

---

### 7. How They Judge Value

**Primary question:**
"How does this persona evaluate whether something is worth their time or money? What signals credibility to them? What signals 'this isn't for me'?"

**Follow-ups:**
- "What makes them trust a creator or expert?"
- "What are their filters? What do they look for before committing?"
- "What makes them immediately skeptical?"

---

### 8. What Makes Them Leave

**Primary question:**
"What makes this persona unsubscribe, refund, disengage, or quietly disappear? What breaks the relationship?"

**Follow-ups:**
- "What makes them feel like they wasted their time or money?"
- "What tone, content, or behavior alienates them?"
- "What would make them feel like they're not the right fit?"

---

### 9. How They Talk About the Problem

**Primary question:**
"If this persona were venting to a friend about the problem you solve — what words would they use? What's the rant?"

**Follow-ups:**
- "What specific phrases come up when they describe their frustration?"
- "How do they frame the problem — is it their fault, the system's fault, luck?"
- "What do they Google when they're stuck?"

---

### 10. Where They Hang Out

**Primary question:**
"Where does this persona spend their attention online and offline? What platforms, communities, newsletters, podcasts, events?"

**Follow-ups:**
- "Who else do they follow or pay attention to in your space?"
- "Where do they go to learn, to complain, to find people like them?"
- "Where are they NOT — what platforms or communities are they absent from?"

---

### 11. Relationship with Paying

**Primary question:**
"How does this persona think about spending money on what you offer? Is money the constraint, or is it something else — time, trust, proof?"

**Follow-ups:**
- "What's their internal justification for spending?"
- "What would make them feel like the investment was justified?"
- "What makes them hesitate — even if they can afford it?"
- "If they're expensing it or sharing it with someone, what do they need to say to justify it?"

---

### 12. Day in the Life

**Primary question:**
"Walk me through a typical day for this persona. Not idealized — real. What are they doing, what are they dealing with, when does your content or product enter their world?"

**Follow-ups:**
- "When do they read, learn, or engage with content like yours?"
- "What's pulling their attention in other directions?"
- "When are they most receptive — what mode are they in?"

---

### 13. Before and After

**Primary question:**
"What does this persona's situation look like BEFORE they have your solution? Then specifically — what does it look like AFTER?"

**Pushback trigger:** If either side is abstract, push: "Make it concrete. What are they doing on a Tuesday morning before vs. after? What's no longer happening? What's happening instead?"

---

### 14. What They've Already Tried (Persona-Specific)

**Primary question:**
"Specifically for this persona — what have they tried before? Different personas will have tried different things. What's the history for this one?"

**Follow-ups:**
- "Why didn't those things work for them specifically?"
- "What did those failures teach them — and how does that affect their skepticism now?"

---

### 15. How They Describe You to Others

**Primary question:**
"If this persona was recommending you to a friend — what would they say? Give me the actual sentence."

**Why this matters:** This is word-of-mouth copy. It's also a proxy for what transformation they actually experienced vs. what you think you delivered.

---

## PUSHBACK RULES

These apply throughout the entire interview:

**"Too vague" trigger phrases to watch for:**
- "They want to grow"
- "They want to be successful"
- "They want to save time"
- "They're entrepreneurs / small business owners / creators"
- "They care about quality"
- "They're frustrated with their current situation"

When you hear these, stop and redirect: "That describes half the internet. Give me the specific version — what does that look like for THIS person in THEIR situation?"

**"Only one persona" trap:**
If they keep defaulting to one persona, ask: "Is there a meaningful difference between someone who's been in their field for 2 years vs. 10 years? Between someone employed and someone independent? Between someone who's tried everything and someone who's just starting?" Find the real splits.

**"Abstract before/after" trap:**
"More confident" and "less stressed" are not transformations. Push for behavioral, situational specificity every time.

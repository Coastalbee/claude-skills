# Audience Profile — Output Template

Use this template to produce the final .md file. Every bracketed section must be filled with specific, concrete details from the interview — not generic descriptions. If a section reads like it could belong to anyone, rewrite it.

Tone: Warm, specific, a little literary. Written like a smart person describing real humans — not a marketing textbook.

---

```markdown
# [Business/Brand Name] — Audience Profile

## Purpose

This file gives Claude deep context on who [Name]'s audience is. Use it whenever working on: content writing, marketing copy, offer creation, pricing decisions, product decisions, CTAs, landing pages, email sequences, or any communication that needs to land with the right people.

**How to use this file:**
- **Writing content:** Match tone, examples, and depth to the persona most likely reading that piece. When content serves multiple personas, lead with the overlap.
- **Marketing & CTAs:** Use the conversion triggers and decision moments specific to each persona. Don't write generic CTAs — write ones that speak to a real fear or desire.
- **Offer creation & pricing:** Reference each persona's relationship with money, time, and value.
- **Product decisions:** Check new features or products against what each persona actually needs.

---

## The Shared DNA

Before the individual profiles — what every [audience name] has in common:

**[Key shared truth #1].** [1-2 sentences of specific elaboration.]

**[Key shared truth #2].** [1-2 sentences.]

**[Key shared truth #3].** [1-2 sentences.]

**Shared motivations:**
1. [Specific motivation]
2. [Specific motivation]
3. [Specific motivation]
4. [Specific motivation]
5. [Specific motivation]

**The shared gap they're trying to close:** [One specific sentence describing the distance between where they are and where they want to be.]

**The two enemies they're fighting:**
- *External:* [The system, trend, industry, or circumstance they're up against]
- *Internal:* [The fear, pattern, or story they're fighting inside themselves]

**Shared language and references:** [The shorthand, phrases, cultural touchstones, insider language that makes them feel understood. Written as prose, not a list.]

**What they've already tried:** [What solutions they've attempted before finding [Name]. What failed and why — at the group level.]

**How they found [Name]:** [The most common path into [Name]'s world — search, referral, social, etc. What they were looking for or doing when they arrived.]

---

## Persona [#]: [PERSONA NAME IN CAPS]

**Profile:** [2-3 sentences describing who this person is, their situation, and what stage of life or work they're in. Specific, not demographic.]

### What They Call Themselves
[The label or identity they use. Why the specific word matters for copy.]

### What They Want
[Their primary goal — not the surface desire, but the real one underneath. What would make this feel worth it.]

### What They Fear
[Their specific fear — the 2am thought, not generic anxiety. The exact thing that makes their stomach drop.]

### Conversion Triggers
[The emotional moments that make them decide to act. What they see, hear, or feel that makes them think "I need this."]

### The Decision Moment
[The specific situation or circumstance — not just the emotion, but the actual event — that pushes them from interested to acting now.]

### How They Judge Value
[What signals credibility to them. Their filters before committing. What makes them immediately skeptical.]

### What Makes Them Leave
[What breaks the relationship. What makes them feel like they wasted their time or money. What alienates them.]

### How They Talk About the Problem
[Their exact language when describing their frustration — the words, phrases, and framing they use. Written close to how they'd actually say it.]

### Where They Hang Out
[Platforms, communities, newsletters, podcasts, events. Who else they follow. Where they're notably absent.]

### Relationship with Paying
[How they think about spending money on this. Whether money, time, or trust is the real constraint. Their internal justification. What makes them hesitate even when they can afford it.]

### Day in the Life
[A real Tuesday for this person. What they're doing, what's pulling their attention, when [Name]'s content or product enters their world. What mode they're in when they're most receptive.]

### Before and After
- *Before:* [Specific situation. What their work or life actually looks like. What they're doing, feeling, struggling with.]
- *After:* [Specific transformation. What's different on a Tuesday afternoon. What they're no longer doing. What they're doing instead.]

### What They've Already Tried
[Solutions specific to this persona — the courses, tools, approaches they've attempted. Why those things didn't work for them specifically. What skepticism that history created.]

### How They Describe [Name] to Others
*"[The actual sentence they'd say to a friend. Written as a direct quote — warm, specific, credible.]"*

---

[Repeat persona section for each additional persona]

---

*Last updated: [Date]*
*Built with: [List any Core files used — Voice Profile, Brand Strategy, Offers & Products]*
```

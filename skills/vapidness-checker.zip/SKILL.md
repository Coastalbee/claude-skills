---
name: vapidness-checker
description: >
  Run six vapidness markers (Specificity, Stakes, POV, Tension, Variation,
  Surprise) on any content and return a scored marker-by-marker diagnostic.
  Each marker scores 1 to 5; when 3+ fall below 3, the content is vapid. After
  the report, offers diagnostic suggestions (no rewrites). Use whenever a user
  wants to check for vapidness, substance, fluff, hollowness, or generic
  writing. Trigger on "is this vapid," "check for substance," "does this say
  anything," "vapidness check," "is this hollow," "is this generic," "check
  for fluff," or pasting content and asking if it commits to something. Also
  trigger when someone says "something feels off but I can't name it." Works
  on articles, newsletters, transcripts, voiceover scripts, white papers, and
  any medium-to-long content. Runs on shorter content with reduced-accuracy
  caveat.
---

# The Vapidness Checker

This skill flips a substance lens onto the user's own work. It comes from a
simple observation: content that actually says something is committed to
something. A specific detail. A position that could be wrong. A voice behind
the words. A tension that doesn't resolve neatly. Take away the commitment and
you're left with the shape of content without the content.

The six markers below test for that commitment. Each one isolates a different
dimension of substance. A single marker failing might not mean much on its own.
Some writing is specific but takes no position, some takes bold positions but
never acknowledges friction. What matters is the pattern. When three or more
markers fail at the same time, the content is vapid.

The skill diagnoses. It does not rewrite. After the report, offer to walk
through diagnostic suggestions that point to specific passages and name what's
missing. The user does the fixing.

## Before you start

### Length check

This skill works best on medium-to-long-form content (roughly 500+ words):
articles, blog posts, newsletter editions, video transcripts, voiceover
scripts, white papers, case studies.

If the user pastes content under ~500 words (a social post, a short email, a
Substack Note), flag it before running:

> "This piece is on the shorter side for the vapidness markers. Some of them,
> especially Variation and Surprise, need more runway to score accurately. I
> can still run it, but the results may be less reliable. Want me to go ahead?"

If the user says yes, proceed. Weight the hard markers (Specificity, Stakes,
POV) more heavily and treat Variation and Surprise as informational rather than
decisive for the overall verdict.

### User context

Consider whatever you know about the user: their voice, their brand, their
audience, their goals. If you have access to voice profiles, brand documents,
audience personas, or any other context that helps you understand what
"substance" means for this particular person, factor that in. A technical
white paper and a personal essay have different substance profiles, and the
user's own context tells you which standard to apply.

Do not ask the user to provide files or point to specific documents. Work with
what you have.

## The six markers

### 1. Specificity: does this name things?

Vapid content talks about "approaches" and "strategies" in language that could
apply to any topic. Substantive content names the strategy, who used it, what
happened when they did.

In psychology, construal level theory describes how abstract language creates
psychological distance and concrete language pulls things close. Vapid content
lives in the abstract because nothing can be wrong if nothing is specific.

**Scoring 1 to 5:**

- **1 (Abstract throughout).** You could swap the topic for a completely
  different one and the sentences still work. No names, no numbers, no
  examples, no "who did what and what happened."
- **2 (Mostly abstract)** with occasional gestures toward specifics that
  never land ("many companies," "various tools," "some experts").
- **3 (Mixed).** Some concrete details exist but they're outnumbered by
  categorical language. The piece names a few things but drifts into
  generality between them.
- **4 (Mostly specific).** Named examples, real details, identifiable
  references. The abstract passages feel like connective tissue between
  specifics, not the main event.
- **5 (Grounded).** The piece names things consistently. Strategies have
  names, people have identities, claims have contexts. You could not swap
  the topic without rewriting most of it.

### 2. Stakes: does this commit to a claim that could be wrong?

Harry Frankfurt defined bullshit as communication indifferent to whether it's
true or false. Vapid content doesn't commit to anything because committing
means risking being challenged.

**Scoring 1 to 5:**

- **1 (No commitments).** The piece describes what exists without ever
  saying whether it works, matters, or should be done differently. You
  finish it unable to say what the author was arguing for or against.
- **2 (Weak hedging).** There are gestures toward positions ("this could
  be important," "it's worth considering") but nothing that a reader could
  push back on.
- **3 (One real claim)** buried in otherwise non-committal prose. The piece
  has a position but seems uncomfortable holding it.
- **4 (Clear position)** that runs through most of the piece. The author is
  arguing something, and a reasonable person could disagree with it.
- **5 (Committed throughout).** The piece takes a position, names the
  consequences of being wrong, and doesn't retreat into "it depends" when
  the argument gets uncomfortable.

### 3. POV: does this argue from somewhere, or balance everything into neutrality?

Substantive content has a person behind the argument who deliberately chose
a side. Linguists call this "stance," the deliberate choices a writer makes
about what to emphasize and what to commit to. Vapid content hedges everything
because commitment requires a person.

**Scoring 1 to 5:**

- **1 (No author visible).** The piece reads like it was assembled from
  summaries. You cannot answer "who is saying this?" There is no
  perspective governing the selection of what's included.
- **2 (Faintly present).** There's an occasional "I think" or "in my
  experience," but it doesn't shape the argument. The piece still accounts
  for all perspectives equally.
- **3 (Present but cautious).** The author shows up but keeps hedging with
  "on the other hand" to the point where the perspective cancels itself out.
- **4 (Clear voice with a clear lens).** You can tell who is writing this
  and what they care about. The selection of evidence and framing reflects
  a deliberate point of view.
- **5 (Unmistakably authored).** The piece could only have been written by
  someone with this particular set of experiences, opinions, and stakes.
  The author's perspective is the organizing principle.

### 4. Tension: does this acknowledge that something is contested or unresolved?

The real world involves friction, so real thinking involves friction too.
Rhetorical theory calls this "rebuttal," the acknowledgment that reasonable
people might disagree, that the evidence cuts both ways. Vapid content skips
this because it never actually argued against something in the first place.

**Scoring 1 to 5:**

- **1 (No friction anywhere).** Every sentence reinforces the same point.
  Nothing is complicated, nothing is contested, nothing cuts both ways.
  The piece reads like a brochure.
- **2 (Token acknowledgment).** There might be a "of course, there are
  challenges" line, but it's disposed of in one sentence and never
  shapes the argument.
- **3 (Tension exists but isn't explored).** The piece names a
  contradiction or a complication, then moves on without sitting with it.
- **4 (Genuine tension).** At least one real contradiction or unresolved
  question lives in the piece, and the author doesn't rush to flatten it.
  The reader feels the friction.
- **5 (The tension is structural).** The piece is organized around
  something contested or unresolved. The author acknowledges where their
  own argument gets uncomfortable or where the evidence doesn't fully
  cooperate.

### 5. Variation: does this shift in rhythm and direction?

When information is easy to process, people judge it as more truthful.
Cognitive fluency creates a false sense of substance. Content that reads at
one speed from start to finish triggers that judgment automatically.

Real thinking has peaks and valleys. It speeds up during some parts and slows
down for the complicated ones. The technical terms are perplexity (how
unpredictable the next word is) and burstiness (how much the sentence rhythm
varies). Uniform text is a hallmark of machine-generated or heavily templated
content.

**Scoring 1 to 5:**

- **1 (Monotone).** Same sentence length, same rhythm, same energy from
  start to finish. Reading it aloud, your voice never changes pace or
  register. It flows like elevator muzak.
- **2 (Slight variation)** that feels accidental rather than purposeful.
  Maybe one sentence is shorter, but the overall pace is flat.
- **3 (Some shifts)** in rhythm or energy, but the piece still has long
  stretches that feel uniform. The variation exists but doesn't feel
  deliberate.
- **4 (Purposeful rhythm).** The pace changes when the content changes.
  Complicated ideas get more room, punchy ideas land short. Reading it
  aloud, your voice would actually modulate.
- **5 (Dynamic and authored).** The piece has a rhythm that belongs to
  a person. Sentence length varies widely, energy shifts with the
  argument, and the variation feels like a deliberate performance choice.

### 6. Surprise: does this include at least one idea you didn't expect?

Substantive content makes you pause at least once. Humans respond to
unexpected and interesting connections. Vapid content conforms. It tells
you what you already expected to hear about the topic.

**Scoring 1 to 5:**

- **1 (Entirely predictable).** If you read the title, you could have
  written every point yourself. Nothing is new, reframed, or unexpected.
  You close the tab and cannot name one thing you didn't already know.
- **2 (One minor novelty)** that doesn't really change anything. A
  slightly different phrasing of a common idea, maybe.
- **3 (A decent insight)** lives in the piece, but it's surrounded by
  expected territory. The piece earns a moment of interest.
- **4 (Genuinely interesting).** At least one idea, connection, or framing
  that you would not have arrived at on your own. The piece teaches or
  reframes something.
- **5 (Multiple surprises).** The piece connects things you wouldn't have
  connected, reframes what you thought you knew, or introduces ideas that
  change how you think about the topic. You want to tell someone about it.

## Verdict logic

The verdict is pattern-based, not an average. A piece can score a 2 on
Surprise and a 5 on everything else and still be substantive. Some writing
is thorough rather than surprising. What the markers catch is the pattern of
hollowness: when multiple dimensions of commitment fail simultaneously.

**How to score the overall verdict:**

Count how many markers score 3 or below (the "below threshold" count).

- **0 to 1 markers below threshold = Substantive.** The content commits to
  something real across most dimensions. Note any individual marker that
  flagged, but the piece passes.
- **2 markers below threshold = Mixed.** The content has substance in some
  dimensions but is slipping in others. Worth examining whether the weak
  markers undermine the overall argument.
- **3+ markers below threshold = Vapid.** The pattern is clear. The content
  has the shape of substance without the commitment. Multiple dimensions
  of hollowness are compounding.

Present the verdict clearly. Name the pattern, not just the number. "Four of
six markers scored below 3. This piece is hedging on position, avoiding
specifics, and smoothing out every friction point. The commitment isn't there"
is more useful than "Overall: Vapid."

## Session flow

1. **Receive the content.** Accept pasted text, a file, a URL to fetch, or
   any input the user provides. If the content is under ~500 words, run the
   length check and wait for the user's go-ahead.

2. **Read the full piece.** Read it completely before scoring anything.
   Understand the argument, the structure, the voice. Factor in the user's
   context if you have it. A deeply technical piece aimed at specialists
   operates differently from a general-audience essay.

3. **Score each marker.** Go through all six markers, one at a time. For
   each one, assign a score (1 to 5) and write a short explanation that
   points to specific evidence in the text. Quote or reference passages that
   illustrate the score. If a marker scores 3 or below, name what's
   missing and where.

4. **Deliver the verdict.** Apply the verdict logic. Present the overall
   read, then the marker-by-marker breakdown.

5. **Offer diagnostics.** After the report, ask:

   > "Want me to walk through specific suggestions for where the substance
   > is thin?"

   If the user says yes, go into diagnostic mode (see below). If not,
   the session is done.

## Output format

Use this structure for the report. Keep it readable. This is a diagnostic
for a human making decisions about their content, not a data dump.

```
## Vapidness Check

**Content:** [title or first line, for reference]
**Length:** [word count]
**Overall verdict:** [Substantive / Mixed / Vapid]. [1-2 sentence
  pattern description]

---

### Marker scores

**Specificity:** [score]/5
[2-3 sentences. What's named and grounded vs. what's abstract. Reference
specific passages.]

**Stakes:** [score]/5
[2-3 sentences. Where the piece commits to a claim vs. where it hedges.
Reference specific passages.]

**POV:** [score]/5
[2-3 sentences. Whether a person is visible behind the argument. Reference
specific passages.]

**Tension:** [score]/5
[2-3 sentences. Where friction exists vs. where everything is smoothed
into agreement. Reference specific passages.]

**Variation:** [score]/5
[2-3 sentences. Whether the rhythm and energy shift or stay flat.
Reference specific passages.]

**Surprise:** [score]/5
[2-3 sentences. Whether the piece includes anything unexpected. Reference
specific passages.]

---

**Pattern:** [X] of 6 markers scored 3 or below.
[Name the pattern in plain language. Which markers failed together and
what that combination means for the content.]
```

A few rules for the output:

- Reference specific passages or sections in every marker explanation.
  "The opening three paragraphs describe five tools without naming any of
  them" is useful. "The specificity could be improved" is not.
- Keep the tone direct and neutral. This is a diagnostic, not a
  performance review. The goal is to help the user see what's there and
  what isn't.
- Do not soften a low score. If the content is vapid, say so clearly and
  name the pattern. The user came here to find out.
- Do not rewrite anything in this phase. Diagnosis only.

## Diagnostic suggestions (optional phase)

When the user asks for suggestions after the report, walk through each marker
that scored 3 or below. For each one:

1. **Point to the specific passage(s)** where the marker fails.
2. **Name what's missing.** Not "add more specifics" but what specific
   thing is absent. "This paragraph describes 'a common framework for
   evaluating risk' without naming the framework, who developed it, or
   where the user would find it. The specificity fails because there's
   nothing to hold onto."
3. **Name why it matters for this particular piece.** Connect the missing
   element back to the argument or the audience. "Without naming the
   framework, this section can't build the credibility the next section
   depends on."

Do not provide rewrites. Do not draft alternative sentences. The
diagnostic tells the user what's absent and why it matters. They write
the fix.

If the user pushes for rewrites, explain that this skill is diagnostic
only, and suggest they take the diagnostics to their editing tools or
process.

## What this skill will not do

- It will not rewrite, rephrase, or draft alternative copy.
- It will not evaluate voice, style, grammar, or mechanical correctness.
  Those belong to other tools.
- It will not score content on quality, persuasiveness, or engagement
  potential. It measures one thing: whether the content commits to
  substance or gestures at it.
- It will not guarantee that substantive content is good content. A piece
  can score 5/5 on every marker and still be wrong, boring, or
  poorly written. The markers test for commitment, not quality.
- It will not treat its own scores as final verdicts. Every score is
  evidence for the user to weigh, not a ruling. The user knows their
  content, audience, and intent better than any checklist.

## Edge cases

- **Intentionally neutral content** (a balanced explainer, a literature
  review, a FAQ): POV and Stakes may legitimately score low. Note this
  in the report rather than penalizing it. "This reads as a deliberate
  explainer rather than an argument, so the low Stakes and POV scores
  reflect the format, not a failure of substance."
- **Transcripts and spoken content**: Variation will score differently
  because speech has natural rhythm variation that written prose doesn't.
  Adjust expectations and note the medium.
- **Content the user didn't write** (they're evaluating someone else's
  work): Run the same markers but adjust the diagnostic suggestions to
  be observational rather than prescriptive.

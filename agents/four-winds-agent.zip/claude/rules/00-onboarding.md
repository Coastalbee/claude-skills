# Rule: Thesis Intake Onboarding

Always run this check before starting the FOUR WINDS process.

## Condition

The user has not provided a specific thesis, argument, strategic position, product thesis, hot take, or public claim.

## Action

HALT the pressure test and ask for the intake using Skill `00-intake`.

## If a Thesis Exists

If the user provides a clear thesis but leaves out context, ask for missing context only when it materially changes the critique. Otherwise proceed and state the assumptions in the output.

## Minimum Required Input

Do not run the FOUR WINDS process without at least:

- The thesis or public-facing claim
- The audience or platform, if inferable
- The desired use case, if inferable

If audience or use case is missing and cannot be inferred, ask for it before running.

# Execution Rules

1. **Default intensity is Medium.** Use Light or Brutal only when the user asks.
2. **Every persona label must begin with an emoji.** Use exactly:
   - `❄️ Boreas:`
   - `🏛️ Notus:`
   - `👥 Eurus:`
   - `⏳ Zephyrus:`
   - `🧭 Synthesizer:`
3. **Run the FOUR WINDS independently.** Do not reference another wind's findings inside a wind pass.
4. **Synthesize after all FOUR WINDS speak.** The synthesis is where interactions, compound risks, and reinforcing repairs belong.
5. **Do not produce a numeric score.** Use a pressure map with holds, wobbles, breaks, evidence gaps, and repairs.
6. **No generic critique.** Every critique must name the exact assumption, reader reaction, precedent, counterargument, or time-based failure mode.
7. **No fabricated evidence.** If evidence would strengthen or weaken a claim, mark it as `Evidence Needed`.
8. **No ceremonial mythology.** Use wind names as role labels only.
9. **Do not rewrite by default.** Offer revision directions and optional thesis variants only inside the final synthesis.
10. **Save outputs without overwriting.** Follow Skill `02-pressure-map-output`.

# Scope Boundaries

Before execution, classify the input.

## In Scope

- Public-facing thesis
- Strategic position
- Product thesis
- Hot take
- Essay, newsletter, or article claim
- Founder narrative
- Consulting or board argument
- Response to public criticism
- Launch, category, or market argument

## Out of Scope

- Private emotional processing
- Pure copyediting
- General brainstorming without a claim
- Fact certification without sources
- Legal, medical, investment, or compliance advice
- Personal attacks on named private people

## Borderline Inputs

If the user gives only a topic, convert it into a thesis candidate and ask:

> "Do you want me to pressure-test this as a thesis? If yes, paste the claim you want tested or tell me the position you are considering."

If the thesis depends on recent or disputed facts, flag the facts as `Evidence Needed` unless reliable source material is provided or research tools are available.

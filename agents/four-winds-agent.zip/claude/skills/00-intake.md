# Skill: FOUR WINDS Intake

Run this skill when the user wants a thesis pressure-tested but has not provided enough context.

## STEP 1: Ask for the Intake

Ask the user to provide as much of this as possible:

```markdown
## FOUR WINDS Intake

1. Thesis / claim:
2. Where this will appear:
3. Intended audience:
4. Stakes if this lands badly:
5. Evidence, examples, or reasoning behind it:
6. Known objections:
7. Desired reader action:
8. Voice or brand constraints:
9. Intensity: Medium by default, or choose Light / Brutal
```

## STEP 2: Interpret Partial Answers

If the user gives a partial intake, proceed only if the thesis is clear and the audience or platform can be inferred.

If the thesis is clear but the context is thin, state assumptions in the output under `Intake Snapshot`.

## STEP 3: Normalize the Thesis

Before the wind passes, extract:

- Thesis in one sentence
- Target audience
- Publication context
- Stakes
- Evidence base
- Known objections
- Intensity

If the user gives multiple possible theses, ask them to choose one. Do not pressure-test multiple theses in one run unless explicitly asked.

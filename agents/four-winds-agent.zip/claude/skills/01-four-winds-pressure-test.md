# Skill: FOUR WINDS Pressure Test

Execute this skill after the intake has passed `00-onboarding` and `01-scope-assessment`.

## STEP 1: Load the Personas

Read the four wind persona files:

- `claude/personas/boreas-steelman.md`
- `claude/personas/notus-historian.md`
- `claude/personas/eurus-audience-proxy.md`
- `claude/personas/zephyrus-time-test.md`

Then read:

- `claude/personas/synthesizer.md`

## STEP 2: Set Critique Intensity

Use the user's requested intensity, or Medium by default.

| Intensity | Behavior |
| --- | --- |
| Light | Gentle, exploratory, useful for early drafts |
| Medium | Direct, diagnostic, specific, default for publication prep |
| Brutal | Adversarial and unsparing, but never insulting or performative |

## STEP 3: Run Four Isolated Passes

Run each wind as a separate pass against the same intake snapshot.

Each pass must produce:

- The main pressure it detects
- The hidden assumption it exposes
- The strongest version of the critique
- What would make the thesis more defensible
- Evidence needed, if applicable

The four wind passes must not cite each other.

## STEP 4: Run the Synthesis Pass

After all FOUR WINDS have completed, run `🧭 Synthesizer:` using all four outputs.

The synthesis must identify:

- Where the thesis holds
- Where it wobbles
- Where it breaks
- Compound risks created by interactions between winds
- Reinforcement moves
- Optional revision directions
- Evidence gaps to close before publishing

## STEP 5: Finalize Output

Proceed to Skill `02-pressure-map-output`.

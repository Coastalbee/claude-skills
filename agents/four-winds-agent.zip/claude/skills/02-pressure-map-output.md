# Skill: Pressure Map Output Format

Follow this format when producing the final FOUR WINDS result.

## File Specification

Save to:

`Output/YYYY-MM-DD_four-winds-[thesis-slug].md`

Use today's actual date. Slugify the thesis using lowercase letters, numbers, and hyphens. Remove special characters. If the file already exists, append `-2`, `-3`, etc. Never overwrite.

## Content Structure

```markdown
# FOUR WINDS Pressure Map: [Short Thesis Name]
**Generated:** [timestamp]
**Intensity:** [Light / Medium / Brutal]
**Platform / setting:** [where this will appear]
**Audience:** [intended audience]

---

## Intake Snapshot

**Thesis:** [one sentence]
**Stakes:** [what happens if it fails]
**Evidence base:** [provided evidence or "thin"]
**Known objections:** [provided objections or "none provided"]
**Assumptions used:** [only if needed]

---

## Wind Readings

### ❄️ Boreas: Steelman Pressure

**Main pressure:** ...
**Hidden assumption:** ...
**Strongest opposing case:** ...
**What would make it more defensible:** ...
**Evidence Needed:** ...

### 🏛️ Notus: Historical Pressure

**Main pressure:** ...
**Precedent pattern:** ...
**What history would warn against:** ...
**What would make it more defensible:** ...
**Evidence Needed:** ...

### 👥 Eurus: Audience Pressure

**Main pressure:** ...
**Likely misread:** ...
**Likely dismissal:** ...
**What would make it more defensible:** ...
**Evidence Needed:** ...

### ⏳ Zephyrus: Time Pressure

**Main pressure:** ...
**Six-month failure mode:** ...
**Two-year failure mode:** ...
**Five-year failure mode:** ...
**What would make it more defensible:** ...

---

## 🧭 Synthesizer: Pressure Map

### Holds

- ...

### Wobbles

- ...

### Breaks

- ...

### Compound Risks

- ...

### Reinforcement Moves

1. ...
2. ...
3. ...

### Optional Revision Directions

- Light revision: ...
- Structural revision: ...
- Stronger version: ...

### Before Publishing

- ...
```

## Low Context Alert

If the intake was too thin to test fairly, include:

```markdown
## Low Context Alert

This pressure map is provisional because the intake lacked:

- [missing context]

The next run will be stronger if you provide:

- [specific requested detail]
```

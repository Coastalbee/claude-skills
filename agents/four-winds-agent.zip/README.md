## What FOUR WINDS Does

FOUR WINDS pressure-tests a public-facing thesis before it goes live.

Most critique workflows test one angle: a devil's advocate pass, a skeptical friend, a quick mental walk-through, or an AI prompt that says "be critical." FOUR WINDS tests four distinct failure modes, then synthesizes the interaction between them.

The output is not a grade. It is a pressure map showing where the thesis holds, wobbles, breaks, and needs reinforcement.

---

## What to Give FOUR WINDS

Give the agent as much context as you can:

- The thesis or claim, preferably in the exact language you plan to publish
- The platform or setting where it will appear
- The intended audience
- The stakes of being wrong, misunderstood, or dismissed
- The evidence, examples, or reasoning behind the thesis
- Known objections or sensitivities
- Desired reader action
- Voice, tone, or brand constraints
- Preferred intensity: Light, Medium, or Brutal

If you do not choose an intensity, FOUR WINDS starts at Medium.

---

## Built For

FOUR WINDS is for founders, consultants, creators, strategists, and writers who publish ideas with reputational exposure.

Use it before:

- Publishing a hot take
- Announcing a strategic position
- Pitching a product thesis
- Sending a board memo
- Responding to public critique
- Turning a strong intuition into a public argument

---

## Core Capabilities

| Capability | What it means |
| --- | --- |
| Intake Expansion | Collects enough context to test the thesis fairly |
| ❄️ Boreas | Builds the strongest opposing case |
| 🏛️ Notus | Finds historical precedents and repeated failure patterns |
| 👥 Eurus | Simulates how real readers may misread or reject the argument |
| ⏳ Zephyrus | Tests the thesis across future time horizons |
| 🧭 Synthesizer | Turns the four passes into a single pressure map |

---

## What FOUR WINDS Is NOT For

FOUR WINDS is not a ghostwriter, fact-checking replacement, legal reviewer, investment adviser, or general-purpose editor.

It can flag evidence gaps and public-risk patterns. It should not fabricate sources, certify factual claims, or make professional decisions for the user.

---

## Output

FOUR WINDS saves a markdown pressure map to:

`Output/YYYY-MM-DD_four-winds-[thesis-slug].md`

Every wind and the synthesizer speak with an emoji before their name:

- `❄️ Boreas:`
- `🏛️ Notus:`
- `👥 Eurus:`
- `⏳ Zephyrus:`
- `🧭 Synthesizer:`

# Objects and verbs

The object gives you the look. The verb gives you the interaction.

These are starting points, not a menu. The best object is usually one the person and their audience *already* associate with the work, which means it often isn't on this list. Use the entries to show what a well-formed idea looks like, then find theirs.

## Contents

- Finding their own object
- Library shelf (articles, essays, newsletters)
- Clothing rail / wardrobe (fashion, apparel)
- Case-file lab (client work, case studies)
- Contact sheet / lightbox (photography, visual work)
- Sample drawer (materials, design systems, products with variants)
- Record crate (music, podcasts, episodes)
- Recipe box / index cards (recipes, methods, short resources)
- Specimen cabinet (collections, research, catalogues)

---

## Finding their own object

1. **List the nouns of their world.** These are the things that turn up in their work, studio, references and audience's mental picture. Ask which objects, materials and places already matter to them; don't provide a ready-made aesthetic.
2. **Pick the one the content already wants to be.** Articles want to be books. Shirts want to hang. Case studies want to be files with evidence in them. If you have to explain the link, it's probably the wrong object.
3. **List the verbs people perform with that object in real life.** With a book you scan spines, pull one out, look at the cover, open it, put it back.
4. **Map each verb to a page action.** Scanning spines becomes browsing; pulling one out becomes hovering or selecting; opening becomes reading the details; putting it back becomes closing.
5. **Keep the page's job obvious.** Whatever the object, people must still be able to find, read, buy or contact without a tutorial.
6. **Name the gimmick risks out loud.** Deciding what you won't do is part of the design.

## Library shelf

- **Fits:** articles, essays, newsletters, reports, anything with titles worth reading on a spine.
- **Look cues:**
  - spines of varied height and width;
  - titles running down the spine;
  - cloth texture with a rounded-spine shading;
  - bands and gilt rules;
  - a small publisher mark at the foot;
  - a wooden shelf with planks and a back wall;
  - a few books leaning.
- **Verbs and what happens on the page:**
  - *Move along the shelf:* sideways scroll with arrows and the mouse wheel.
  - *Pick out a book:* hovering lifts the spine and its front cover pops up above it.
  - *Open it:* the book comes forward closed, its cover swings open, and the page shows the title, date and a read link.
  - *Put it back:* close returns focus to the spine.
- **Phone form:** books lie flat in small piles with horizontal titles, so the text stays readable. Flat books can't tilt.
- **Gimmick risks:** rooms and multiple sections, category labels, stars, photoreal 3D, books too small to read.

## Clothing rail / wardrobe

- **Fits:** apparel, accessories, anything sold by the piece.
- **Look cues:** garments hanging at slightly different heights, hangers and a rail, fabric texture, swing tags carrying price and size.
- **Verbs:**
  - *Slide along the rail:* sideways browse.
  - *Pull a piece forward:* it swings to face you, with the tag showing.
  - *Look closer:* details, fabric and sizes.
  - *Take it to the counter:* add to bag, which stays conventional and obvious.
- **Phone form:** one garment at a time, swiped like flicking through the rail.
- **Gimmick risks:** a dressing-room fantasy that hides the price, or physics animations that slow down buying.

## Case-file lab

- **Fits:** consultants, agencies, studios, investigators of any kind.
- **Look cues:** manila folders with tabs, stamps, paper-clipped evidence, typed labels, a desk or filing drawer.
- **Verbs:**
  - *Flick through the drawer:* browse tabs.
  - *Open a file:* the folder opens to show the brief, then the evidence (before and after, numbers, quotes).
  - *Follow the story:* problem, then what changed, then the result.
- **Phone form:** a stack of folders, each opening full-screen.
- **Gimmick risks:** detective-board string and pins (too theatrical), or burying the outcome under the props.

## Contact sheet / lightbox

- **Fits:** photographers, illustrators, visual artists.
- **Look cues:** a grid of frames with film-strip edges and frame numbers, a loupe, grease-pencil marks on the selects, a glowing lightbox.
- **Verbs:**
  - *Scan the sheet:* a grid at a glance.
  - *Loupe a frame:* a magnified preview follows the pointer.
  - *Pull a select:* it opens large on the lightbox, with notes.
- **Phone form:** one strip at a time, with tap to loupe.
- **Gimmick risks:** tiny thumbnails, or fake film grain over the actual work.

## Sample drawer

- **Fits:** materials, paint, textiles, design systems, products with many variants.
- **Look cues:** shallow drawers, swatches in slots, labels with codes, felt lining.
- **Verbs:**
  - *Open a drawer:* a category slides out.
  - *Lift a swatch:* it comes up with its details.
  - *Compare:* lay two swatches side by side.
- **Phone form:** one drawer per screen, with swatches in a scrollable tray.
- **Gimmick risks:** too many drawers, or labels you can't read.

## Record crate

- **Fits:** music, podcasts, mixes, episode archives.
- **Look cues:** sleeves standing in a crate, worn edges, sticker labels, a turntable or player.
- **Verbs:**
  - *Flick through:* sleeves tilt forward one at a time.
  - *Pull a record:* the sleeve comes out and the cover shows.
  - *Play:* the player starts, which must be a real, obvious control.
- **Phone form:** a swipeable crate, one sleeve at a time.
- **Gimmick risks:** auto-playing audio, or making the play control hard to find.

## Recipe box / index cards

- **Fits:** recipes, methods, short how-tos, prompt libraries.
- **Look cues:** a wooden or tin box, card dividers, handwritten-style headings, splashes and stains (in moderation).
- **Verbs:**
  - *Thumb through:* cards tilt as you pass them.
  - *Pull a card:* it lifts out and flips for the method.
  - *Pin it:* save it or print it.
- **Phone form:** one card full-screen, swiped through.
- **Gimmick risks:** handwriting fonts that are hard to read, or stains over the instructions.

## Specimen cabinet

- **Fits:** collections, research, catalogues, ideas libraries.
- **Look cues:** glass-fronted drawers, pinned specimens, typed specimen labels, brass details.
- **Verbs:**
  - *Browse the cabinet:* drawers of related items.
  - *Inspect:* a specimen comes forward with its label expanded.
  - *Cross-reference:* related specimens light up.
- **Phone form:** one drawer at a time, with tap to inspect.
- **Gimmick risks:** dusty Victorian cosplay that buries the actual content.
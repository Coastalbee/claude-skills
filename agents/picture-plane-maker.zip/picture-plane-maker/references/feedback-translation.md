# Feedback translation

People who can't code are often extremely precise about what feels wrong. They just say it in visual language. Your job is to hear the concrete problem inside the reaction.

Treat these as patterns, not fixed recipes. The useful fix depends on the person's object, page and existing design. When feedback is vague, ask for a marked screenshot or a reference before guessing.

| They say | What's probably wrong | What to try |
|---|---|---|
| "These still look like rectangles" / "too flat" | The chosen object's defining features are missing | Identify the actual object's shape, materials, edges, proportions and physical cues; restore those before adding decoration. Restrained, not photoreal. |
| "I don't want a generic modal" | The reveal breaks the object | Continue the chosen object's behaviour: a file unfolds, a garment swings round, a specimen drawer opens. Animate from where the item actually was on screen, not from the middle of nowhere. |
| "Too much going on" / "remove the extra labels" | AI added taxonomy and decoration | Remove the labels, categories, rooms, badges and dividers nobody asked for. One strong idea beats five small ones. |
| "Too clean" / "too digital" | No material quality | Paper texture, slight irregularity, aged colour. Use it in moderation, and be ready to dial it back later. |
| "Too big" / "too small" | Scale isn't tied to the screen | Scale the whole object together (spines, type and shelf) rather than retuning each part. Tie the size to the screen's height when the goal is one screen. |
| "The text is too small on my phone" | The desktop form doesn't suit phones | Change the object's arrangement for phones (for example, a dense contact sheet becomes a swipeable set of larger images) rather than shrinking everything. |
| "These don't look like the object anymore" | The defining details got lost in a rearrangement | Restore the object's recognisable structure and visual cues. Ask which details made an earlier version feel right, and preserve those. |
| "Kinda thick" / "chunky" | Text is wrapping into too many lines | Give the text more room: make items longer, trim padding, move secondary details out of the way. |
| "Physics don't work like that" | The interaction breaks real-world logic | Fix the underlying rule, not one instance: stacked objects need support, hinged parts open from their hinge, and hanging objects need a believable anchor. Use the chosen object's real behaviour. |
| "The labels don't fit" | Text is sized without looking at the available space | Size text from the room actually left on each item. Fix the shared sizing rule, not individual labels one by one. |
| "Centre it between X and Y" | Spacing comes from guesses, not real reference points | Measure from the real edges (bottom of the menu, top of the shelf) and centre in that space. |
| "I don't want it to scroll" | Content is taller than the screen | Fit the page to one screen. Shrink the object on shorter screens, and hide extras such as the footer on that page only. |
| "I can't tell what I'm hovering" | No preview while browsing | Show the item's identity near the pointer, if a preview helps, without covering the item or relying on hover for essential information. |
| "Make the preview bigger" | The preview is too timid | Enlarge it and allow deliberate overlap, while keeping the selected item visible and ensuring the preview doesn't block interaction. |
| "It should open from the item I clicked" | The transition has no origin | Measure where the item is on screen and animate the opened version out of that exact spot and size. |
| "Speed it up a bit" | The animation drags | Shorten the whole thing by about a third and keep the order of the beats (arrive, pause, open). |
| "Only show the title, date and the small text" | Too much content in the reveal | Cut it back to what they named, and keep the controls (read and close) so it still works. |
| "Same font on everything in there" | Mixed typefaces inside one object | Use one family across everything printed on or in the object. Leave shared pieces (like a cover used elsewhere) alone if changing them would cause a visible jump. |
| "Looks bad, revert" | The experiment didn't land | Remove every trace of it. Don't argue the case. |
| "Make it pop" / "more premium" | Nothing concrete yet | Ask for a reference or a marked screenshot, or offer two clearly different directions to react to. |
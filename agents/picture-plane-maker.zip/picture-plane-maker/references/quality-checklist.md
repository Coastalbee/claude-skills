# Quality checklist

Run this before calling something done, and again before it goes live. If you can't view the page yourself, turn the relevant items into a short "open it and check these" list for the person. People can check far more than they think, if you tell them exactly where to look.

## Every screen size

- [ ] **Phone (about 375px wide):** does the object still make sense, or does it need its own phone form?
- [ ] **Tablet and small laptop:** check the in-between widths, where layouts often break.
- [ ] **Short screens (a laptop around 700px tall):** does anything important fall below the fold that was meant to fit?
- [ ] **No sideways scrolling of the whole page by accident.** Only the parts that are meant to scroll should scroll.
- [ ] **Changes scoped to one size really stayed there.**

## Text and legibility

- [ ] Text fits inside its shapes (spines, cards, tags) at every size, including the longest title.
- [ ] Text is large enough to actually read, not just decoratively present.
- [ ] Contrast between text and background is strong enough, including text placed on textures.

## Keyboard and screen readers

- [ ] Every item can be reached with Tab, and focus is clearly visible.
- [ ] Enter or Space opens an item. Esc closes it, and focus returns to where it was.
- [ ] Items are real buttons or links, not clickable boxes.
- [ ] Each item has a sensible accessible name (its title, plus the date if useful).
- [ ] Decorative duplicates (like a preview cover repeating the title) are hidden from screen readers.

## Motion

- [ ] With "reduce motion" switched on, everything still works and shows its end state without the animation.
- [ ] Animations are short enough not to feel slow on the tenth use.
- [ ] Hover-only features have a fallback, or aren't needed, on touch screens.

## Behaviour

- [ ] The page's real job (read, buy, contact) is still obvious, with no tutorial needed.
- [ ] Links open where they should (for example, external posts in a new tab).
- [ ] Nothing nobody asked for crept in (filters, labels, extra sections).
- [ ] Reverted experiments left nothing behind.

## Build health

- [ ] No new dependency for something CSS or the existing stack already does.
- [ ] Existing errors elsewhere in the project are flagged separately, not mixed into this change.
- [ ] The project's own rules were followed: rules files, formatting, line endings, and whether agents may start dev servers or builds.

## Going live

- [ ] The change is in version control (or backed up) and easy to roll back.
- [ ] It ships the project's usual way, and the person confirmed before anything was published.
- [ ] Anything touching payments, logins or personal data got a technical review.
- [ ] Any writing about the page (article, case study, docs) still matches what was built.
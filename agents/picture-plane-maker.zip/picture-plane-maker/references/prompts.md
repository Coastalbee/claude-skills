# Prompts

Use these prompts in two ways:

- In a **chat-only assistant**, hand them to the person to fill in and paste into their coding agent.
- In a **coding agent**, use them as your own checklist for what to ask and what to report back.

Square brackets are the bits they fill in. Stay in one coding-agent conversation from the handoff onwards, so the agent keeps the context of the site and the decisions already made.

## Contents

1. Find your version (any AI)
2. Handoff: inspect before building (coding agent)
3. Make one version you can judge (coding agent)
4. Refine what's on the screen (coding agent, repeat)
5. Quick experiment (coding agent, any time)

---

## 1. Find your version

Use this with whatever AI they already talk to, before any code exists.

```text
I want to rethink [PAGE / COLLECTION] on my website.

Right now it contains:
[WHAT IS BEING PRESENTED]

The larger world around this work includes things like:
[OBJECTS, MATERIALS, PLACES, FORMATS, REFERENCES, RITUALS, VISUAL CUES, RECURRING DETAILS]

A visitor still needs to be able to:
[THE BASIC JOB OF THE PAGE: BROWSE, READ, COMPARE, BUY, CONTACT, INSPECT, ETC.]

Before suggesting an interface, ask me a few useful questions about the work and the page if you need more context.

Then give me 3 genuinely different interaction concepts that grow from the world I described.

For each concept, explain:
- what physical object, place or format it borrows from;
- what the visitor would actually do;
- why that behaviour belongs to this work;
- what should stay conventional so the page remains easy to use;
- what would make the idea feel gimmicky or overdesigned.

Do not code anything yet.
Do not give me generic industry ideas.
Do not suggest a metaphor just because it looks cute.

At the end, tell me which concept you think is strongest and why.

Once I choose one, turn it into a short INTERACTION CONCEPT I can carry into a coding-agent conversation. Include:
- the physical object / place / format;
- the main visitor actions;
- the basic page function that must stay obvious;
- the visual cues that matter most;
- the things that would make the idea feel generic or gimmicky.
```

If an answer feels immediately wrong, telling the AI so is useful. Stop brainstorming once the idea sounds like something that could actually belong to them.

## 2. Handoff: inspect before building

Paste the interaction concept first, then this.

```text
I want to transform [PAGE / SECTION] on my existing website.

Right now, this page:
[DESCRIBE WHAT IT CURRENTLY SHOWS AND HOW PEOPLE USE IT]

The thing I am presenting is:
[ARTICLES / PRODUCTS / CASE STUDIES / PROJECTS / PHOTOGRAPHS / RESOURCES / OTHER]

The interaction concept I want to explore is:
[PASTE THE INTERACTION CONCEPT YOU CREATED ABOVE, OR DESCRIBE THE OBJECT / PLACE / FORMAT AND THE VISITOR ACTIONS]

The visitor should be able to:
[ACTION 1]
[ACTION 2]
[OPTIONAL ACTION 3]

The larger visual / creative world around this work is:
[DESCRIBE THE ATMOSPHERE, MATERIALS, REFERENCES, COLOURS, TYPOGRAPHY, IMAGE STYLE, OR OTHER DETAILS THAT ALREADY BELONG TO IT]

The most important physical or visual cues are:
[CONCRETE DETAILS THAT MAKE THE IDEA FEEL LIKE THE OBJECT / PLACE / FORMAT]

Please keep:
[CONTENT, NAVIGATION, DATA, COLOURS, TYPE, EXISTING BEHAVIOUR OR OTHER PARTS THAT ALREADY WORK]

Please remove or avoid:
[GENERIC UI, EXTRA LABELS, MODALS, FILTERS, DECORATIVE CLUTTER, OR ANYTHING ELSE THAT BREAKS THE IDEA]

References:
[REFERENCE IMAGE / URL / EXISTING PAGE / SCREENSHOT / STYLE DESCRIPTION]

The page still needs to remain:
[OBVIOUS, LEGIBLE, RESPONSIVE, KEYBOARD-ACCESSIBLE, EASY TO BUY / READ / CONTACT / NAVIGATE, ETC.]

Please inspect the existing implementation before changing anything.

First tell me:
1. how you would translate this physical idea into actual visitor behaviour;
2. which current components, styles and data you would reuse;
3. which files you plan to change;
4. what you would leave untouched;
5. any risks or conflicts you see with the current architecture, accessibility, responsive behaviour or data structure.

Do not rebuild unrelated parts of the site.

Do not code yet. Give me the plan first.
```

Check the plan before anything changes. If it misunderstood the interaction, or plans to rebuild something they want to keep, correct that first.

## 3. Make one version you can judge

Send this in the same conversation once the plan sounds right.

```text
Using the existing page, the interaction concept we agreed on, and the implementation plan you just described, build one contained first version.

Keep the core behaviour simple and complete enough that I can review it visually.

Please preserve:
[THE PARTS OF THE EXISTING PAGE / SITE THAT MUST SURVIVE]

Please prioritise:
[THE MOST IMPORTANT 3–5 VISUAL OR INTERACTION CUES]

Please do not add:
[UNWANTED DEFAULTS, EXTRA FEATURES, GENERIC UI, FILTERS, MODALS, DECORATIVE CLUTTER]

Modify the existing implementation rather than rebuilding unrelated parts of the site.

After implementing it, tell me what you changed.

If you encounter errors that already existed elsewhere in the project, flag them separately rather than trying to fix the entire codebase.
```

## 4. Refine what's on the screen

This is the one they'll reuse most. It's deliberately repetitive about what must stay, because AI can change fifty things in one pass.

```text
This is closer, but I want to refine the current version rather than start over.

Screenshot: [ATTACH A SCREENSHOT AND CIRCLE OR ARROW THE PART YOU MEAN]

This applies to: [DESKTOP / MOBILE / BOTH]

What is already working:
[DESCRIBE THE PARTS THAT SHOULD STAY EXACTLY OR MOSTLY AS THEY ARE]

What still feels wrong:
[DESCRIBE WHAT YOU SEE IN ORDINARY LANGUAGE]

Please change only:
[THE SPECIFIC OBJECT / INTERACTION / AREA THAT NEEDS WORK]

I want it to feel more like:
[REFERENCE / PHYSICAL OBJECT / MATERIAL / BEHAVIOUR]

The concrete cues I care about are:
- [OBSERVABLE DETAIL 1]
- [OBSERVABLE DETAIL 2]
- [OBSERVABLE DETAIL 3]
- [OPTIONAL DETAIL 4]

Please remove:
[ELEMENTS THAT FEEL GENERIC, CLUTTERED, OFF-WORLD, OR UNNECESSARY]

Please preserve:
[BEHAVIOUR / LAYOUT / CONTENT / DATA / VISUAL DETAILS THAT ARE ALREADY RIGHT]

Interaction-wise, when a visitor [TRIGGER ACTION], I want [RESULTING BEHAVIOUR].

I do NOT want:
[GENERIC MODAL / DRAWER / CARD / PAGE RELOAD / EXTRA FILTER / OTHER UNWANTED DEFAULT]

Before coding, briefly explain what you are going to change and what you will deliberately leave alone.

Then implement the refinement.
```

Most rounds won't need every line. A marked screenshot plus "this applies to desktop" plus one sentence of what's wrong often does the job.

## 5. Quick experiment

Use this for "I wonder what it would look like if…". It's cheap to try and cheap to undo.

```text
Quick experiment, just so I can see it: [CHANGE]. Keep it easy to undo.
```

If it doesn't work:

```text
Revert it.
```

A good revert leaves nothing behind: no leftover styles, no half-used variables.
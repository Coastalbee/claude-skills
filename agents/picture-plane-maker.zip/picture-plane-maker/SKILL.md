---
name: picture-plane-maker
description: The Picture Plane Maker helps someone turn one flat part of their website (an archive, product grid, portfolio, case studies, resource list) into an interaction that belongs to their world, like a library of books, a clothing rail or a case-file lab. Then plan it, build it with a coding agent, direct it until it feels right, test it and ship it. Made for people who can't code and talk in plain language. Use this whenever someone wants a page to "feel like" something, says their archive or grid or portfolio feels generic or flat, describes a page they can picture but can't build, wants to "turn my X into a Y", mentions websites where items behave like physical objects, or is mid-build giving visual feedback such as "it still looks like coloured rectangles" or "I don't want a generic modal", even if they never say "interaction design". Works in a chat-only assistant (concept plus coding-agent handoff) and in a coding agent with access to the site's code (the full build).
---

# The Picture Plane Maker

Read `references/workflow.md` before doing anything else, and follow it. It holds the whole process (finding the object, planning, building, directing, testing, shipping) and points to the other reference files when they're needed.
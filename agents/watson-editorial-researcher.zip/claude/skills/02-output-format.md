# Skill: Idea Output Format

Follow this exact format when outputting ideas from the Ideation Pipeline.

## FILE SPECIFICATION
Save to: `outputs/YYYY-MM-DD_topic-slug.md`
Use today's actual date. Slugify the topic: lowercase, spaces to hyphens, remove special characters.

## CONTENT STRUCTURE
```markdown
# Topic Research: [Original Topic Input]
**Generated:** [timestamp]
**Categories activated:** [list all categories used — always-on + which situational ones and why]

---

## Research Table

| # | Category | Finding | Source | URL | Relevance Notes |
|---|----------|---------|--------|-----|-----------------|
| 1 | ... | ... | ... | ... | ... |

---

## Top 5 Content Ideas

### Idea 1: [Suggested Title]

**Combo type:** [e.g., Psychological framework + cultural reference + technical risk]

**Angle:** [Contrarian / Explainer-with-depth / Unexpected analogy]

**The connection:** [2-3 sentence paragraph explaining WHY these things connect. Demonstrate genuine cross-domain thinking. Show the structural or conceptual similarity.]

**Suggested title:** [Title]

**Suggested subtitle:** [Subtitle]

**One-line hook:** [Draft opening sentence to start writing from]

**Controversy level:** [Safe / Spicy / Nuclear]

**Why this fits your brand:** [2-3 sentences explaining which specific brand pillars/audiences this aligns with]

**Scores:**

| Timeliness | Brand Fit | Originality | Combo Strength | Engagement |
|------------|-----------|-------------|----------------|------------|
| [H/M/L] | [H/M/L] | [H/M/L] | [H/M/L] | [H/M/L] |

**Sources:**
- [Source name](url)

**Adjacent ideas:**
- If you like this angle, you could also explore...

---

### Idea 2: ...
```

## LOW SIGNAL ALERT (Edge Case)
If fewer than 8-10 meaningful findings were found across all categories, prepend or append this section to the bottom of the output file:

```markdown
## ⚠️ Low Signal Alert

Research on this topic was thin. Here's what was sparse and why:
[Explain what categories had weak signal]

**Adjacent topics that would likely yield richer research:**
- [Topic 1]
- [Topic 2]
```

# Skill: Idea Generation Pipeline

Execute this skill when a topic is received and has passed the `00-scope` assessment.

## STEP 1: WIDE RESEARCH SWEEP

Search broadly across the web. Target 20+ distinct sources.

- **Strategy:** 2-3 broad queries on the topic, followed by targeted queries per always-on research category (e.g., `[topic] reddit opinions`, `[topic] psychological framework`), and situational categories.
- **Platforms:** General web (news, blogs), Reddit (threads, AMAs — apply Rule 03-reddit-crawling and use markdown.new), Forums (Hacker News), YouTube.

## STEP 2: CATEGORIZE FINDINGS

Organize all findings into the following research categories:

### Always-On Categories

1. **Breaking news / recent developments**
2. **Hot takes & opinions** (X, Reddit, blogs)
3. **Contrarian voices**
4. **Psychological / behavioral frameworks** (loss aversion, status games, etc.)
5. **Analogies from other domains**

### Situational Categories (activate when relevant)

1. **Business / monetization angles**
2. **Technical deep-dives**
3. **Cultural / meme layer**
4. **Historical parallels**
5. **Data & stats**
6. **Regulatory / legal implications**
7. **Creator / builder stories**
8. **Failure modes / cautionary tales**

## STEP 3: BUILD THE RESEARCH TABLE

Compile findings into a structured table (15–30 rows) with the following columns:
`| # | Category | Finding | Source | URL | Relevance Notes |`
Do not filter aggressively at this stage.

## STEP 4: LOAD AND ANALYZE BRAND DOCUMENTS

Read `claude/rules/02-data-source-config.md` to determine the brand doc location, then fetch and read those files (via API or local read). Extract:

- Core brand themes and content pillars
- Positioning statements and recurring angles
- Audience segments
- Voice characteristics explicitly utilized or avoided

## STEP 5: CROSS-POLLINATE AND GENERATE IDEAS

Find cross-domain connections between research findings and brand positioning. Target:

- **Explainer-with-depth:** trending topic + psych framework + brand connection
- **Contrarian:** mainstream opinion + opposing evidence + brand-aligned reframe
- **Unexpected analogy:** unrelated domain pattern mapped onto a brand-relevant topic

Select top 5 ideas based on Surprise (non-obvious), Natural fit (not forced), Audience interest, Substance, Avoidance of restricted territory, and different angles.

## STEP 6: SCORE IDEAS

Score each idea (High/Medium/Low) on:

- **Timeliness** (Hot right now vs Evergreen)
- **Brand Fit** (Natural connection to pillars)
- **Originality** (Fresh vs Done-to-death)
- **Combo Strength** (Surprising/non-obvious connection)
- **Engagement Potential** (Reaction/share/reply potential)

Proceed to Skill `02-output-format` to finalize output.
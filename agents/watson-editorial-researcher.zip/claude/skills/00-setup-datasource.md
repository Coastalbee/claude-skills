# Skill: Data Source Setup Workflow

Run this skill ONLY when `claude/rules/03-data-source-config.md` contains `STATUS: UNCONFIGURED`.

## STEP 1: Assess Current Capabilities
Before asking the user, check your currently running tools and active MCP (Model Context Protocol) servers in your environment.
- Check what tools are available (e.g., Notion MCP, Google Drive MCP).
- See if there are existing configuration files or agent memories pointing to brand folders.

## STEP 2: Ask the User
If the location isn't immediately obvious from your existing environment, ask the user:
> *"Where do you host your core brand documents? (e.g., an absolute path to a local folder, or an external workspace like Notion/Drive via an MCP server?)"*

## STEP 3: Configure and Validate Connection
Based on the user's response:

**If Local Folder:**
- Ask for the absolute path.
- Using your file-reading tools, run an `ls` or equivalent command to verify the folder actually exists and contains markdown files.

**If External Data (e.g., Notion, Github, Google Drive):**
- Verify that you have the appropriate MCP server running to access that data.
- If the MCP is NOT installed, guide the user to configure it (e.g., giving them the exact terminal command to start or connect to that specific MCP server).
- Ask the user for the specific resource identifier (like a Notion Database ID or a Drive Folder path).
- Run a test fetch via the MCP tool to ensure you have successful read access.

## STEP 4: Save Configuration
Once the data source is validated, use your file-writing tools to update `claude/rules/03-data-source-config.md`. Overwrite the UNCONFIGURED status and write the integration details into this file so the `01-idea-generation-pipeline` knows exactly how to fetch the docs in the future.

Example for Local Folder:
```yaml
data_source: local
fetch_strategy: file_read
path: /Users/dan/Documents/brand-guidelines
```

Example for MCP Server (Notion):
```yaml
data_source: mcp_notion
fetch_strategy: mcp_search_database
database_id: 8b4a2...
```

## STEP 5: Confirm
Confirm to the user that the data source is successfully mapped and saved as a persistent rule, and prompt them to provide their first topic to start generating ideas.

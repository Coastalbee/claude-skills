# Rule: Reddit Content Fetching

Always apply this rule implicitly whenever your research pipeline discovers a Reddit URL that needs to be read.

**Condition:** You are about to fetch, read, or scrape a URL containing `reddit.com`.

**Action:** You **MUST** prepend `https://markdown.new/` to the start of the URL before attempting to fetch it.

**Example:**
- Discovered URL: `https://www.reddit.com/r/ClaudeAI/comments/1rgcxpo/...`
- Fetch URL: `https://markdown.new/https://www.reddit.com/r/ClaudeAI/comments/1rgcxpo/...`

**Why:** Reddit aggressively blocks standard AI web scrapers and fetches (returning 403 Forbidden). Using `markdown.new` bypasses this limitation and returns perfectly structured markdown containing both the post and the comment discourse, which is critical for signal extraction.

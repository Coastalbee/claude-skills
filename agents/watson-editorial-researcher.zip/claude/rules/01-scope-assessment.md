# Scope Boundaries & Topic Assessment

Before doing anything else, assess whether the topic is **searchable** or **personal/non-searchable**.

- **Searchable**: a show, product, trend, technology, cultural moment, public figure, news event, industry development, meme, etc.
- **Personal/non-searchable**: a private conversation, personal feeling, vague internal observation, anecdote with no external referent.

**If personal/non-searchable**, pause and ask exactly this:
> *"This seems personal — should I research related themes online, or just riff on this using your brand docs?"*

- If user says **"research"**: extract 2-3 searchable themes from the topic (e.g., from "weird pricing conversation with a client" -> "pricing psychology," "client negotiation dynamics," "value communication") and proceed with those as the research topic.
- If user says **"riff"**: skip Steps 2–4 (Wide Research Sweep, Categorize Findings, Build Research Table) entirely. Jump to Step 5 (load brand docs) and generate ideas purely from brand positioning + the topic as a creative prompt.

**If searchable**, proceed immediately to Step 2 (Wide Research Sweep). Do not ask any questions.

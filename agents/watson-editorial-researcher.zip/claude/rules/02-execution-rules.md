# Execution Rules & Persistent Memory Constraints

1. **One clarifying question maximum** — only for personal/non-searchable topics. Never ask questions about brand docs, output format, or research approach.
2. **Never overwrite output files** — each run creates a new file.
3. **Save to the designated** `outputs/` **folder.**
4. **Read all** `.md` **files** from the local brand folder every run. No indexing or skipping.
5. **No shallow combinations** — if a connection requires stretching logic, discard it.
6. **Diverse idea set** — the 5 generated ideas must represent different combo types, sources, and angles.
7. **The connection paragraph is sacred** — demonstrate genuine cross-domain thinking, not just keyword matching.

## Persistent Agent Memory

Update memory (`claude/agent-memory/`) as you discover patterns:

- Brand pillars or voice characteristics inferred from documents.
- Topics or angles already covered (to avoid repetition).
- Combination types or frameworks that produced High scores across multiple runs.
- Research categories that consistently produce strong signal.
- Topics that produced Low Signal Alerts.